import { useState } from 'react';
import demoVideoRaw from './assets/demo.mp4';

// Large data: addresses often fail for video on phones. Turn the embedded data
// into a Blob address, which plays reliably. Hosted file addresses pass through.
export function blobUrlFromDataUrl(src: string): string {
  if (!src.startsWith('data:')) return src;
  try {
    const bin = atob(src.slice(src.indexOf(',') + 1));
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return URL.createObjectURL(new Blob([bytes], { type: 'video/mp4' }));
  } catch {
    return src;
  }
}

// Demo video with fallbacks: Blob address, then the original address, then a message.
export function DemoVideo() {
  const [src, setSrc] = useState(() => blobUrlFromDataUrl(demoVideoRaw));
  const [failed, setFailed] = useState(false);

  function handleError() {
    if (src !== demoVideoRaw) setSrc(demoVideoRaw);
    else setFailed(true);
  }

  if (failed) {
    return <p className="demo-fallback">The video could not load. Please refresh the page.</p>;
  }
  return (
    <video
      src={src}
      autoPlay
      muted
      loop
      playsInline
      preload="auto"
      controls
      aria-label="Screen recording of a mavvlink page"
      onError={handleError}
    />
  );
}

import markWhite from './assets/mark-white.png';
import manuelGif from './assets/manuel.gif';
import { ArrowUpRight } from 'lucide-react';

// A phone showing an example mavvlink page, drawn in HTML and CSS so it always displays.
export function PhoneMockup() {
  return (
    <div className="mock-screen" role="img" aria-label="An example mavvlink business page on a phone">
      <div className="mock-notch" />
      <div className="mock-body">
        <img src={manuelGif} alt="" className="mock-avatar" />
        <b className="mock-name">Manuel</b>
        <span className="mock-sub">Creative studio · Lagos</span>
        <div className="mock-link primary">Explore our work <ArrowUpRight size={12} /></div>
        <div className="mock-link">Book a consultation <ArrowUpRight size={12} /></div>
        <div className="mock-link">Chat on WhatsApp <ArrowUpRight size={12} /></div>
        <div className="mock-card">
          <small>FEATURED SERVICE</small>
          <b>Brand identity design</b>
          <span>From ₦250,000</span>
        </div>
        <div className="mock-foot">Made with <b>mavvlink.</b></div>
      </div>
    </div>
  );
}
