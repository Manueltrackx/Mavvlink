import { useState, type ReactNode } from 'react';
import { CurrencyPicker, formatPrice, type CurrencyCode } from './currency';
import { cleanSlug, validateSignup, type SignupDraft } from './signup';
import { Wordmark } from './brand';
import { SiteFooter } from './footer';
import { TEMPLATE_PRESETS } from './templates';
import { FREE_TEMPLATE_IDS } from './access';
import { Globe } from './globe';
import { PhoneMockup } from './demo';
import markWhite from './assets/mark-white.png';
import { ArrowUpRight, Check, ChevronRight, Link2, Menu, MessageCircle, ShieldCheck, Sparkles, Store, X } from 'lucide-react';

export type MenuItem = { label: string; view?: string; hash?: string };

export const MENU_GROUPS: { label: string; items: MenuItem[] }[] = [
  {
    label: 'Product',
    items: [
      { label: 'Features', hash: 'features' },
      { label: 'Templates', view: 'templates' },
      { label: 'Examples', view: 'examples' },
      { label: 'Pricing', view: 'pricing' },
    ],
  },
  {
    label: 'Company',
    items: [
      { label: 'About', view: 'about' },
      { label: 'Services', view: 'services-info' },
      { label: 'Contact', view: 'contact' },
      { label: 'Changelog', view: 'changelog' },
      { label: 'Affiliate', view: 'affiliate' },
    ],
  },
  {
    label: 'Help',
    items: [
      { label: 'Help center', view: 'help' },
      { label: 'Terms', view: 'terms' },
      { label: 'Privacy', view: 'privacy' },
    ],
  },
];


export const EXTRA_VIEWS = [
  'templates', 'examples', 'analytics', 'billing', 'settings', 'login', 'signup', 'onboarding', 'affiliate',
  'help', 'contact', 'pricing', 'terms', 'privacy', 'changelog', 'notfound',
] as const;
export type ExtraView = (typeof EXTRA_VIEWS)[number];

export type Plan = { name: string; price: string; ngn: number; note: string; features: string[] };

type Props = {
  view: ExtraView;
  go: (view: string) => void;
  onSignIn: () => void;
  onSignOut: () => void;
  user: any;
  plans: Plan[];
  currency: CurrencyCode;
  onCurrencyChange: (c: CurrencyCode) => void;
  onSignUp: (d: SignupDraft) => void;
  referralUrl: string;
  onSubscribe: (email: string) => Promise<string | null>;
  subscriber: boolean;
};



function Frame({ go, user, onSignIn, onSignOut, onSubscribe, children }: {
  go: (v: string) => void; onSubscribe: (email: string) => Promise<string | null>; user: any; onSignIn: () => void; onSignOut: () => void; children: ReactNode;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);

  function goMenu(item: MenuItem) {
    setMenuOpen(false);
    if (item.hash) {
      go('home');
      setTimeout(() => document.getElementById(item.hash!)?.scrollIntoView({ behavior: 'smooth' }), 80);
      return;
    }
    go(item.view!);
    window.scrollTo(0, 0);
  }

  return (
    <div className="xp-app">
      <div className="xp-shell">
        <header className="xp-top">
          <button className="xp-brand" onClick={() => go('home')}>
            <Wordmark />
          </button>
          <div className="xp-actions">
            {user ? (
              <button className="btn btn-dark btn-small" onClick={() => go('dashboard')}>Dashboard</button>
            ) : (
              <button className="btn btn-dark btn-small" onClick={onSignIn}>Log in</button>
            )}
            <button
              className="menu-toggle"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={menuOpen}
            >
              {menuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </header>
        {menuOpen && (
          <div className="mobile-menu">
            {MENU_GROUPS.map(group => {
              const open = openGroup === group.label;
              return (
                <div className="menu-group" key={group.label}>
                  <button
                    className="menu-group-toggle"
                    aria-expanded={open}
                    onClick={() => setOpenGroup(open ? null : group.label)}
                  >
                    <span>{group.label}</span>
                    <ChevronRight size={16} className={open ? 'menu-chev open' : 'menu-chev'} />
                  </button>
                  {open &&
                    group.items.map(item => (
                      <button key={item.label} className="menu-item" onClick={() => goMenu(item)}>
                        {item.label} <ChevronRight size={16} />
                      </button>
                    ))}
                </div>
              );
            })}
            <div className="menu-group">
              <div className="menu-group-label">Account</div>
              <div className="menu-actions">
                {user ? (
                  <>
                    <button className="btn btn-dark" onClick={() => { setMenuOpen(false); go('dashboard'); }}>Open dashboard</button>
                    <button className="btn btn-ghost" onClick={() => { setMenuOpen(false); onSignOut(); }}>Sign out</button>
                  </>
                ) : (
                  <>
                    <button className="btn btn-ghost" onClick={() => { setMenuOpen(false); onSignIn(); }}>Log in</button>
                    <button className="btn btn-dark" onClick={() => { setMenuOpen(false); go('signup'); }}>Get started</button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
      <main className="xp-main">
        {children}
      </main>
      <SiteFooter go={go} onStart={() => go('signup')} onLogin={onSignIn} signedIn={!!user} onSignOut={onSignOut} onSubscribe={onSubscribe} />
    </div>
  );
}

const EXAMPLES = [
  { name: 'Ada Okafor Photography', kind: 'Photographer', color: '#9bf36b', links: ['Book a shoot', 'Portfolio', 'Price list'] },
  { name: 'Mama Tee Kitchen', kind: 'Restaurant', color: '#f7b267', links: ['Order on WhatsApp', "Today's menu", 'Find us'] },
  { name: 'Kemi Adeyemi, Coach', kind: 'Consultant', color: '#7aa7ff', links: ['Book a session', 'Free guide', 'Testimonials'] },
];

const CHART = [42, 58, 47, 66, 71, 52, 80, 74, 63, 88, 79, 95, 84, 102];

const FAQ: [string, string][] = [
  ['How do I publish my page?', 'Finish setting up your page in the dashboard. It goes live at your public link as soon as you save it.'],
  ['Can I change my links later?', 'Yes. Add, edit, reorder or remove links at any time from the page builder.'],
  ['Do visitors need an account?', 'No. Anyone with your link can view your page and tap your links.'],
  ['Can I use my own domain?', 'Custom domains are available on the Growth plan and above. Request one from the Custom domain page.'],
  ['What happens if I cancel?', 'Plan details and cancellation terms are on the Pricing page. Contact us if you have questions about a specific case.'],
];

const TERMS: { title: string; paras: string[]; list?: string[] }[] = [
  {
    title: 'About these terms',
    paras: [
      'These terms form an agreement between you and the operator of mavvlink ("mavvlink", "we", "us"). They govern your use of our website, our page builder and the public pages you create (together, the "Service").',
      'By creating an account or using the Service, you agree to these terms. If you do not agree, please do not use the Service.',
    ],
  },
  {
    title: 'Your account',
    paras: [
      'You must give accurate information when you sign up and keep it up to date. You are responsible for everything that happens under your account.',
      'Keep your sign-in details private. Tell us straight away if you suspect someone else has used your account.',
    ],
  },
  {
    title: 'Your page and content',
    paras: [
      'You own the content you add to your page, including text, images, product photos and links. You confirm that you have the rights to use it.',
      'You give us a limited licence to host, store and display your content so that your page works. This licence ends when you delete the content or close your account.',
    ],
  },
  {
    title: 'Acceptable use',
    paras: ['You agree not to use the Service to:'],
    list: [
      'publish anything illegal, fraudulent, hateful or harmful to others',
      'sell or promote goods or services that are prohibited by law',
      'impersonate another person or business, or mislead visitors',
      'send spam, or misuse the newsletter or contact features',
      'upload malware, or try to break, scrape or overload the Service',
    ],
  },
  {
    title: 'Plans, billing and currency',
    paras: [
      'Plans and what they include are listed on the Pricing page. Free accounts can use two templates and add two products. Paid plans unlock more, as set out there.',
      'Plan prices are set in Nigerian naira. Prices shown in other currencies are indicative conversions. Checkout is in naira.',
      'Online payments are not yet connected. When they are, you will be asked to agree to the billing terms at checkout, including renewal and cancellation. Refunds, where offered, will be described at that point.',
    ],
  },
  {
    title: 'Custom domains',
    paras: [
      'Custom domains are available on the Growth plan and above. Each request is reviewed before it goes live, and you must complete the DNS steps we give you.',
      'We may refuse, pause or remove a domain that infringes someone else\'s rights, is used for abuse, or breaks these terms.',
    ],
  },
  {
    title: 'Affiliate programme',
    paras: [
      'The affiliate programme lets you earn by referring businesses to mavvlink. Commission rates, payout schedules and referral rules are set out on the Affiliate page and may change before the programme opens.',
      'Do not promote mavvlink with false or misleading claims. We may withdraw an affiliate who breaks this rule.',
    ],
  },
  {
    title: 'Newsletter',
    paras: [
      'When you subscribe to our newsletter you agree to receive updates and tips from mavvlink by email. Every email will include a way to unsubscribe.',
    ],
  },
  {
    title: 'Our service',
    paras: [
      'We work to keep the Service available and secure, but we do not promise it will be uninterrupted or error-free. We may carry out maintenance, and we may add, change or remove features over time.',
      'The Service is provided "as is" to the extent the law allows.',
    ],
  },
  {
    title: 'Intellectual property',
    paras: [
      'The mavvlink name, logo, design and software belong to us. You may use them only to access and use the Service as these terms allow.',
    ],
  },
  {
    title: 'Suspension and closing your account',
    paras: [
      'We may suspend or close an account that breaks these terms, after telling you where we reasonably can. You can close your account at any time from the dashboard.',
      'When an account closes, your page stops being public. We will keep or delete your data as described in our privacy policy.',
    ],
  },
  {
    title: 'Limitation of liability',
    paras: [
      'To the extent the law allows, we are not liable for indirect or consequential losses, including lost profit or lost sales arising from use of the Service.',
      'Our total liability to you for any claim is limited to the amount you paid us in the 12 months before the claim.',
      'Nothing in these terms limits any rights you have that cannot be limited by law.',
    ],
  },
  {
    title: 'Changes to these terms',
    paras: [
      'We may update these terms from time to time. We will post the new version here and update the date at the top. For significant changes we will tell you by email or in the dashboard.',
      'If you keep using the Service after a change takes effect, you accept the updated terms.',
    ],
  },
  {
    title: 'Governing law',
    paras: [
      'These terms are governed by the laws of the Federal Republic of Nigeria. Disputes will be heard in the courts of Nigeria, unless the law requires another forum.',
    ],
  },
  {
    title: 'Contact us',
    paras: [
      'Questions about these terms? Send us a message from the Contact page and we will reply.',
    ],
  },
];

const LEGAL_SECTIONS = [
  'Who we are', 'What information we collect', 'How we use your information',
  'How we share information', 'Your choices', 'Contact us',
];

/* ---------- Illustrations (SVG and CSS, no external images) ---------- */

function Stage({ chips, children }: { chips?: { icon: ReactNode; pos: string }[]; children: ReactNode }) {
  return (
    <div className="xp2-stage">
      <span className="xp2-ring" />
      <span className="xp2-ring r2" />
      <span className="xp2-glow" />
      {children}
      {chips?.map((c, i) => (
        <span key={i} className={'xp2-chip ' + c.pos}>{c.icon}</span>
      ))}
    </div>
  );
}

function StarCore({ dim = false }: { dim?: boolean }) {
  return (
    <div className={'xp2-core' + (dim ? ' dim' : '')}>
      <img src={markWhite} alt="" />
    </div>
  );
}

function ShieldArt() {
  return (
    <Stage chips={[{ icon: <ShieldCheck size={22} />, pos: 'c1' }, { icon: <Sparkles size={22} />, pos: 'c2' }]}>
      <svg viewBox="0 0 200 220" className="xp2-svg" aria-hidden="true">
        <defs>
          <linearGradient id="xp2-shield" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#a5f477" />
            <stop offset="1" stopColor="#3f7a22" />
          </linearGradient>
        </defs>
        <path d="M100 14 L176 42 V104 C176 152 146 188 100 208 C54 188 24 152 24 104 V42 Z" fill="rgba(165,244,119,0.08)" stroke="url(#xp2-shield)" strokeWidth="3" />
        <path d="M68 112 L92 136 L134 90" fill="none" stroke="#a5f477" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </Stage>
  );
}

function LockArt() {
  return (
    <Stage chips={[{ icon: <Link2 size={22} />, pos: 'c1' }, { icon: <Store size={22} />, pos: 'c3' }]}>
      <svg viewBox="0 0 200 220" className="xp2-svg" aria-hidden="true">
        <path d="M62 98 V72 C62 40 138 40 138 72 V98" fill="none" stroke="#a5f477" strokeWidth="10" strokeLinecap="round" />
        <rect x="42" y="98" width="116" height="92" rx="20" fill="rgba(165,244,119,0.1)" stroke="#a5f477" strokeWidth="3" />
        <circle cx="100" cy="138" r="10" fill="#a5f477" />
        <rect x="97" y="142" width="6" height="22" rx="3" fill="#a5f477" />
      </svg>
    </Stage>
  );
}

function EnvelopeArt() {
  return (
    <Stage chips={[{ icon: <MessageCircle size={22} />, pos: 'c2' }]}>
      <svg viewBox="0 0 220 180" className="xp2-svg wide" aria-hidden="true">
        <rect x="18" y="40" width="184" height="120" rx="18" fill="rgba(165,244,119,0.08)" stroke="#a5f477" strokeWidth="3" />
        <path d="M24 52 L110 112 L196 52" fill="none" stroke="#a5f477" strokeWidth="3" strokeLinejoin="round" />
        <circle cx="34" cy="28" r="5" fill="#a5f477" />
        <circle cx="48" cy="18" r="3" fill="#a5f477" opacity="0.6" />
        <circle cx="184" cy="22" r="4" fill="#a5f477" opacity="0.8" />
      </svg>
    </Stage>
  );
}

function ChatArt() {
  return (
    <Stage chips={[{ icon: <Sparkles size={22} />, pos: 'c3' }]}>
      <svg viewBox="0 0 220 200" className="xp2-svg wide" aria-hidden="true">
        <path d="M26 30 H150 C162 30 170 38 170 50 V84 C170 96 162 104 150 104 H72 L44 126 L48 104 H26 C14 104 6 96 6 84 V50 C6 38 14 30 26 30 Z" fill="rgba(165,244,119,0.1)" stroke="#a5f477" strokeWidth="3" strokeLinejoin="round" />
        <path d="M200 96 H118 C108 96 102 102 102 110 V136 C102 144 108 150 118 150 H132 L150 168 L148 150 H200 C210 150 216 144 216 136 V110 C216 102 210 96 200 96 Z" fill="rgba(165,244,119,0.18)" stroke="#a5f477" strokeWidth="3" strokeLinejoin="round" />
        <circle cx="50" cy="67" r="5" fill="#a5f477" />
        <circle cx="86" cy="67" r="5" fill="#a5f477" />
        <circle cx="122" cy="67" r="5" fill="#a5f477" />
      </svg>
    </Stage>
  );
}

function ChartArt() {
  const bars = [38, 52, 44, 66, 58, 79, 70, 92];
  return (
    <div className="xp2-chart-art">
      {bars.map((h, i) => (
        <i key={i} style={{ height: `${h}%`, animationDelay: `${i * 0.08}s` }} />
      ))}
    </div>
  );
}

function CardArt() {
  return (
    <div className="xp2-card-art">
      <span className="xp2-card-chip" />
      <b>mavvlink</b>
      <small>•••• •••• •••• 4242</small>
      <span className="xp2-card-glow" />
    </div>
  );
}

function StepsArt() {
  return (
    <div className="xp2-steps">
      <span className="xp2-step">1</span>
      <i className="xp2-step-line" />
      <span className="xp2-step">2</span>
      <i className="xp2-step-line" />
      <span className="xp2-step">3</span>
    </div>
  );
}

function MiniPage({ accent, name, lines }: { accent: string; name: string; lines: string[] }) {
  return (
    <div className="xp2-mock">
      <div className="xp2-mock-av" style={{ background: accent }} />
      <b>{name}</b>
      {lines.map(l => (
        <div key={l} className="xp2-mock-pill">{l}</div>
      ))}
    </div>
  );
}

/* ---------- Layout pieces ---------- */

function Hero({ eyebrow, title, accent, lead, art, children }: {
  eyebrow: string; title: string; accent?: string; lead?: string; art?: ReactNode; children?: ReactNode;
}) {
  return (
    <section className="xp2-hero">
      <div className="xp2-copy">
        <div className="eyebrow"><Sparkles size={14} /> {eyebrow.toUpperCase()}</div>
        <h1 className="xp2-title">
          {title}
          {accent && <span> {accent}</span>}
        </h1>
        {lead && <p className="xp2-lead">{lead}</p>}
        {children}
      </div>
      {art && <div className="xp2-art">{art}</div>}
    </section>
  );
}

function Section({ children }: { children: ReactNode }) {
  return <section className="xp2-section">{children}</section>;
}

/* ---------- Pages ---------- */

function Templates({ go, subscriber }: { go: (v: string) => void; subscriber: boolean }) {
  return (
    <>
      <Hero
        eyebrow="Templates"
        title="Start from a look that fits"
        accent="your business."
        lead="Pick a starting style, then change the colours, links and services to match you. Switch templates any time without losing your links."
        art={<Stage chips={[{ icon: <Store size={22} />, pos: 'c1' }, { icon: <Sparkles size={22} />, pos: 'c2' }]}><StarCore /></Stage>}
      />
      <Section>
        <div className="xp2-tpl-grid">
          {TEMPLATE_PRESETS.map(t => {
            const locked = !subscriber && !FREE_TEMPLATE_IDS.includes(t.id);
            return (
              <div className={'xp2-tpl' + (locked ? ' locked' : '')} key={t.id}>
                <div className="xp2-tpl-thumb" style={{ background: `linear-gradient(165deg, ${t.accent} 0%, #0c0f0a 75%)` }}>
                  <MiniPage accent={t.accent} name={t.name} lines={[t.use]} />
                </div>
                <h3>
                  {t.name} {locked && <em className="lock-badge">Subscribers</em>}
                </h3>
                <p className="xp2-muted">{t.use}</p>
                <p className="xp2-quote">“{t.headline}”</p>
                {locked ? (
                  <button className="btn btn-ghost btn-small" onClick={() => go('pricing')}>
                    Subscribe to use <ArrowUpRight size={15} />
                  </button>
                ) : (
                  <button className="btn btn-lime btn-small" onClick={() => go('signup')}>
                    Use template <ArrowUpRight size={15} />
                  </button>
                )}
              </div>
            );
          })}
        </div>
        <p className="xp2-note">
          Want to see one in action? <button className="xp-inline" onClick={() => go('examples')}>View example pages</button>.
        </p>
      </Section>
    </>
  );
}

function Examples({ go }: { go: (v: string) => void }) {
  return (
    <>
      <Hero
        eyebrow="Examples"
        title="Pages people are building"
        accent="with mavvlink."
        lead="Illustrative examples of the kind of page each business can make. The phone shows an example page built with mavvlink."
        art={<div className="demo-phone"><PhoneMockup /></div>}
      />
      <Section>
        <div className="xp2-tpl-grid">
          {EXAMPLES.map(e => (
            <div className="xp2-tpl" key={e.name}>
              <div className="xp2-ex-av" style={{ background: e.color }}>{e.name[0]}</div>
              <h3>{e.name}</h3>
              <p className="xp2-muted">{e.kind}</p>
              {e.links.map(l => (
                <div className="xp2-mock-pill" key={l}>{l}</div>
              ))}
              <button className="btn btn-lime btn-small" onClick={() => go('signup')}>Make one like this</button>
            </div>
          ))}
        </div>
        <p className="xp2-note">
          Ready to choose a look? <button className="xp-inline" onClick={() => go('templates')}>Browse templates</button>.
        </p>
      </Section>
    </>
  );
}

function Analytics({ go }: { go: (v: string) => void }) {
  return (
    <>
      <Hero
        eyebrow="Analytics"
        title="How your page is"
        accent="doing."
        lead="Sample numbers for this preview. Real numbers appear once your page has visitors."
        art={<ChartArt />}
      />
      <Section>
        <div className="xp2-stats">
          <div className="xp2-stat"><span>Page views</span><b>1,284</b></div>
          <div className="xp2-stat"><span>Link clicks</span><b>412</b></div>
          <div className="xp2-stat"><span>Click rate</span><b>32%</b></div>
        </div>
        <div className="xp2-panel">
          <h3>Views, last 14 days</h3>
          <div className="xp2-bars">
            {CHART.map((v, i) => (
              <i key={i} style={{ height: `${Math.round((v / 102) * 100)}%`, animationDelay: `${i * 0.05}s` }} title={`${v}`} />
            ))}
          </div>
        </div>
        <div className="xp2-two">
          <div className="xp2-panel">
            <h3>Top links</h3>
            {[['Book a call', 168], ['Chat on WhatsApp', 121], ['Portfolio', 73]].map(([label, n]) => (
              <div className="xp2-bar-row" key={label as string}>
                <span>{label}</span>
                <div className="xp2-meter"><i style={{ width: `${Math.round(((n as number) / 168) * 100)}%` }} /></div>
                <b>{n}</b>
              </div>
            ))}
          </div>
          <div className="xp2-panel">
            <h3>Where visitors come from</h3>
            {[['Instagram', 46], ['WhatsApp', 28], ['Direct', 16], ['Google', 10]].map(([label, pct]) => (
              <div className="xp2-bar-row" key={label as string}>
                <span>{label}</span>
                <div className="xp2-meter"><i style={{ width: `${pct}%` }} /></div>
                <b>{pct}%</b>
              </div>
            ))}
          </div>
        </div>
        <p className="xp2-note"><button className="xp-inline" onClick={() => go('dashboard')}>Back to dashboard</button></p>
      </Section>
    </>
  );
}

function Billing({ go, plans }: { go: (v: string) => void; plans: Plan[] }) {
  const last = plans[1]?.price ?? '₦5,000';
  return (
    <>
      <Hero
        eyebrow="Billing"
        title="Your plan and"
        accent="invoices."
        lead="Sample account for this preview."
        art={<CardArt />}
      />
      <Section>
        <div className="xp2-plan-now">
          <div>
            <span className="xp2-tag">Current plan</span>
            <h3>Growth</h3>
            <p className="xp2-muted">{last} · renews 1 January 2027</p>
          </div>
          <button className="btn btn-lime btn-small" onClick={() => go('pricing')}>Change plan</button>
        </div>
        <div className="xp2-two">
          <div className="xp2-panel">
            <h3>Payment method</h3>
            <p className="xp2-muted">Card ending 4242 (sample)</p>
          </div>
          <div className="xp2-panel">
            <h3>Next invoice</h3>
            <p className="xp2-muted">1 January 2027 · {last}</p>
          </div>
        </div>
        <div className="xp2-panel">
          <h3>Invoices</h3>
          {['1 December 2026', '1 November 2026', '1 October 2026'].map(d => (
            <div className="xp2-invoice" key={d}>
              <span>{d}</span>
              <b>{last}</b>
              <em>Paid</em>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}

function Settings({ onSignOut }: { onSignOut: () => void }) {
  const [name, setName] = useState('Mavvlink');
  const [email, setEmail] = useState('owner@mavvlink.example');
  const [light, setLight] = useState(false);
  const [showCount, setShowCount] = useState(true);
  const [saved, setSaved] = useState(false);
  return (
    <>
      <Hero
        eyebrow="Settings"
        title="Account and page"
        accent="settings."
        lead="Your business details, public link and display preferences."
        art={<Stage chips={[{ icon: <Link2 size={22} />, pos: 'c1' }, { icon: <Sparkles size={22} />, pos: 'c3' }]}><StarCore /></Stage>}
      />
      <Section>
        <div className="xp2-panel">
          <label className="xp-field"><span>Business name</span>
            <input value={name} onChange={e => { setName(e.target.value); setSaved(false); }} />
          </label>
          <label className="xp-field"><span>Contact email</span>
            <input value={email} onChange={e => { setEmail(e.target.value); setSaved(false); }} />
          </label>
          <label className="xp-field"><span>Public link</span>
            <input value="/p/mavvlink" readOnly />
          </label>
          <label className="xp-check"><input type="checkbox" checked={light} onChange={e => { setLight(e.target.checked); setSaved(false); }} /> Default to light theme</label>
          <label className="xp-check"><input type="checkbox" checked={showCount} onChange={e => { setShowCount(e.target.checked); setSaved(false); }} /> Show visitor count on my page</label>
          <div className="xp-row">
            <button className="btn btn-lime" onClick={() => setSaved(true)}>Save changes</button>
            {saved && <span className="xp2-muted">Saved in this preview. Nothing is stored.</span>}
          </div>
        </div>
        <div className="xp2-panel xp-row">
          <div>
            <h3>Sign out</h3>
            <p className="xp2-muted">You can sign back in at any time.</p>
          </div>
          <button className="btn btn-ghost btn-small" onClick={onSignOut}>Sign out</button>
        </div>
      </Section>
    </>
  );
}

function Login({ go, onSignIn }: { go: (v: string) => void; onSignIn: () => void }) {
  return (
    <Section>
      <div className="xp2-split">
        <div className="xp2-split-art"><LockArt /></div>
        <div className="xp2-split-copy">
          <div className="eyebrow"><Sparkles size={14} /> LOG IN</div>
          <h1 className="xp2-title">Welcome <span>back.</span></h1>
          <p className="xp2-lead">Sign in to manage your page, links and analytics.</p>
          <div className="xp2-panel">
            <button className="btn btn-lime xp-wide" onClick={onSignIn}>Continue to mavvlink</button>
          </div>
          <p className="xp2-note">New here? <button className="xp-inline" onClick={() => go('signup')}>Create an account</button>.</p>
        </div>
      </div>
    </Section>
  );
}

function Signup({ go, onSignUp }: { go: (v: string) => void; onSignUp: (d: SignupDraft) => void }) {
  const [name, setName] = useState('');
  const [business, setBusiness] = useState('');
  const [email, setEmail] = useState('');
  const [slug, setSlug] = useState('');
  const [slugTouched, setSlugTouched] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const draft: SignupDraft = { name, business, email, slug };
  const errors = validateSignup(draft, accepted);
  const show = (k: string) => touched[k] || touched.submit;
  const touch = (k: string) => setTouched(t => ({ ...t, [k]: true }));
  const canSubmit = Object.keys(errors).length === 0;

  function submit() {
    setTouched(t => ({ ...t, submit: true }));
    if (canSubmit) onSignUp({ ...draft, name: name.trim(), business: business.trim(), email: email.trim() });
  }

  return (
    <Section>
      <div className="xp2-split">
        <div className="xp2-split-art">
          <Stage chips={[{ icon: <Store size={22} />, pos: 'c1' }, { icon: <Sparkles size={22} />, pos: 'c3' }]}><StarCore /></Stage>
        </div>
        <div className="xp2-split-copy">
          <div className="eyebrow"><Sparkles size={14} /> SIGN UP</div>
          <h1 className="xp2-title">Create your <span>free page.</span></h1>
          <p className="xp2-lead">Takes about two minutes. You can change everything later.</p>
          <div className="xp2-panel">
            <label className="xp-field"><span>Your name</span>
              <input value={name} onChange={e => setName(e.target.value)} onBlur={() => touch('name')} placeholder="Ada Okafor" />
              {show('name') && errors.name && <small className="xp-error">{errors.name}</small>}
            </label>
            <label className="xp-field"><span>Business name</span>
              <input
                value={business}
                onChange={e => {
                  setBusiness(e.target.value);
                  if (!slugTouched) setSlug(cleanSlug(e.target.value));
                }}
                onBlur={() => touch('business')}
                placeholder="Northstar Studio"
              />
              {show('business') && errors.business && <small className="xp-error">{errors.business}</small>}
            </label>
            <label className="xp-field"><span>Email</span>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} onBlur={() => touch('email')} placeholder="you@example.com" />
              {show('email') && errors.email && <small className="xp-error">{errors.email}</small>}
            </label>
            <label className="xp-field"><span>Your page link</span>
              <input
                value={slug}
                onChange={e => { setSlugTouched(true); setSlug(cleanSlug(e.target.value)); }}
                onBlur={() => touch('slug')}
                placeholder="northstar-studio"
              />
              <small className="xp2-muted">Your page will be at /p/{slug || 'your-link'}. We confirm the link is free when your page is set up.</small>
              {show('slug') && errors.slug && <small className="xp-error">{errors.slug}</small>}
            </label>
            <label className="xp-check">
              <input type="checkbox" checked={accepted} onChange={e => { setAccepted(e.target.checked); touch('terms'); }} />
              I agree to the <button type="button" className="xp-inline" onClick={() => go('terms')}>Terms</button> and <button type="button" className="xp-inline" onClick={() => go('privacy')}>Privacy policy</button>
            </label>
            {show('terms') && errors.terms && <small className="xp-error">{errors.terms}</small>}
            <button className="btn btn-lime xp-wide" onClick={submit} disabled={touched.submit && !canSubmit}>
              Create my page
            </button>
          </div>
          <p className="xp2-note">Already have an account? <button className="xp-inline" onClick={() => go('login')}>Log in</button>.</p>
        </div>
      </div>
    </Section>
  );
}

function Onboarding({ onSignIn }: { onSignIn: () => void }) {
  const [step, setStep] = useState(1);
  const [business, setBusiness] = useState('');
  const [headline, setHeadline] = useState('');
  const [linkTitle, setLinkTitle] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  return (
    <>
      <Hero
        eyebrow={`Get set up · step ${step} of 3`}
        title="Three steps to your"
        accent="live page."
        lead="Name your business, write one line about it, and add your first link."
        art={<StepsArt />}
      >
        <div className="xp2-progress"><span style={{ width: `${(step / 3) * 100}%` }} /></div>
      </Hero>
      <Section>
        <div className="xp2-panel xp2-narrow">
          {step === 1 && (
            <>
              <h2 className="xp-h2">What's your business called?</h2>
              <label className="xp-field"><span>Business name</span><input value={business} onChange={e => setBusiness(e.target.value)} placeholder="Northstar Studio" /></label>
            </>
          )}
          {step === 2 && (
            <>
              <h2 className="xp-h2">Add a one-line headline</h2>
              <label className="xp-field"><span>Headline</span><input value={headline} onChange={e => setHeadline(e.target.value)} placeholder="Brand strategy for ambitious teams." /></label>
            </>
          )}
          {step === 3 && (
            <>
              <h2 className="xp-h2">Add your first link</h2>
              <label className="xp-field"><span>Link title</span><input value={linkTitle} onChange={e => setLinkTitle(e.target.value)} placeholder="Book a call" /></label>
              <label className="xp-field"><span>Link address</span><input value={linkUrl} onChange={e => setLinkUrl(e.target.value)} placeholder="https://" /></label>
            </>
          )}
          <div className="xp-row xp-between">
            <button className="btn btn-ghost btn-small" disabled={step === 1} onClick={() => setStep(step - 1)}>Back</button>
            {step < 3
              ? <button className="btn btn-lime btn-small" onClick={() => setStep(step + 1)}>Next</button>
              : <button className="btn btn-lime btn-small" onClick={onSignIn}>Finish and open dashboard</button>}
          </div>
        </div>
        <p className="xp2-note">{business || headline || linkTitle ? 'Your answers are kept only in this preview.' : 'You can change everything later.'}</p>
      </Section>
    </>
  );
}

function Help() {
  return (
    <>
      <Hero
        eyebrow="Help"
        title="Answers to the"
        accent="common questions."
        lead="Can't find what you need here? Send us a message from the contact page."
        art={<ChatArt />}
      />
      <Section>
        <div className="xp2-faq">
          {FAQ.map(([q, a]) => (
            <details key={q}><summary>{q}</summary><p>{a}</p></details>
          ))}
        </div>
      </Section>
    </>
  );
}

function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  return (
    <Section>
      <div className="xp2-split">
        <div className="xp2-split-art"><EnvelopeArt /></div>
        <div className="xp2-split-copy">
          <div className="eyebrow"><Sparkles size={14} /> CONTACT</div>
          <h1 className="xp2-title">Get in <span>touch.</span></h1>
          <div className="xp2-panel">
            <label className="xp-field"><span>Your name</span><input value={name} onChange={e => setName(e.target.value)} /></label>
            <label className="xp-field"><span>Email</span><input value={email} onChange={e => setEmail(e.target.value)} /></label>
            <label className="xp-field"><span>Message</span><textarea rows={5} value={message} onChange={e => setMessage(e.target.value)} /></label>
            <button className="btn btn-lime" disabled={!message.trim()} onClick={() => setSent(true)}>Send message</button>
            {sent && <p className="xp2-muted">Thanks. This is a preview, so nothing was sent.</p>}
          </div>
        </div>
      </div>
    </Section>
  );
}

function Pricing({ plans, go, currency, onCurrencyChange }: {
  plans: Plan[]; go: (v: string) => void; currency: CurrencyCode; onCurrencyChange: (c: CurrencyCode) => void;
}) {
  return (
    <>
      <Hero
        eyebrow="Pricing"
        title="Plans for every"
        accent="stage."
        lead="Start free and upgrade when your business grows. Prices show in your currency; checkout is in naira."
        art={<StarCore />}
      >
        <CurrencyPicker value={currency} onChange={onCurrencyChange} />
      </Hero>
      <Section>
        <div className="xp2-plans">
          {plans.map((p, i) => (
            <div className={'xp2-plan' + (i === 1 ? ' featured' : '')} key={p.name}>
              {i === 1 && <span className="xp2-tag">Recommended</span>}
              <h3>{p.name}</h3>
              <p className="xp2-price">{formatPrice(p.ngn, currency)}</p>
              <p className="xp2-muted">{p.note}</p>
              <ul className="xp2-checklist">
                {p.features.map(f => (
                  <li key={f}><Check size={15} /> {f}</li>
                ))}
              </ul>
              <button className={i === 1 ? 'btn btn-lime' : 'btn btn-ghost'} onClick={() => go('signup')}>
                Choose {p.name}
              </button>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}

function Terms() {
  return (
    <>
      <Hero
        eyebrow="Terms & conditions"
        title="The rules for using"
        accent="mavvlink."
        lead="Last updated 22 November 2026. Please read these terms before you create your page."
        art={<ShieldArt />}
      />
      <Section>
        <div className="xp2-draft-note">
          <ShieldCheck size={18} />
          <p>Draft for review. These terms are a starting point. Have a qualified lawyer review them before you launch.</p>
        </div>
        <nav className="xp2-toc" aria-label="Terms contents">
          {TERMS.map((t, i) => (
            <a key={t.title} href={`#terms-${i + 1}`}>{i + 1}. {t.title}</a>
          ))}
        </nav>
        <div className="xp2-articles">
          {TERMS.map((t, i) => (
            <article className="xp2-article" id={`terms-${i + 1}`} key={t.title}>
              <div className="xp2-article-head">
                <span className="xp2-num">{i + 1}</span>
                <h2>{t.title}</h2>
              </div>
              {t.paras.map(p => (
                <p key={p}>{p}</p>
              ))}
              {t.list && (
                <ul className="xp2-checklist">
                  {t.list.map(li => (
                    <li key={li}><Check size={15} /> {li}</li>
                  ))}
                </ul>
              )}
            </article>
          ))}
        </div>
      </Section>
    </>
  );
}

function Legal({ kind }: { kind: 'terms' | 'privacy' }) {
  const title = kind === 'terms' ? 'Terms of service' : 'Privacy policy';
  return (
    <>
      <Hero
        eyebrow={title}
        title={kind === 'terms' ? 'The rules for using' : 'How we handle your'}
        accent={kind === 'terms' ? 'mavvlink.' : 'information.'}
        lead="Draft placeholder. Replace with reviewed legal text before launch."
        art={<ShieldArt />}
      />
      <Section>
        <div className="xp2-legal-grid">
          {LEGAL_SECTIONS.map(s => (
            <div className="xp2-panel" key={s}>
              <h3>{s}</h3>
              <p className="xp2-muted">[Section text to be written and reviewed.]</p>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}

function Affiliate({ go, user, referralUrl }: { go: (v: string) => void; user: any; referralUrl: string }) {
  const [copied, setCopied] = useState(false);
  const message = `Build your business page on mavvlink: ${referralUrl}`;
  return (
    <>
      <Hero
        eyebrow="Affiliate programme"
        title="Earn by referring"
        accent="businesses."
        lead="Share your link. When a business you refer signs up, you earn a share of what they pay."
        art={<Globe />}
      />
      <Section>
        <div className="xp2-steps-grid">
          <div className="xp2-panel"><span className="xp2-num">1</span><h3>Share your link</h3><p className="xp2-muted">Send it to customers, on social media or in groups.</p></div>
          <div className="xp2-panel"><span className="xp2-num">2</span><h3>They sign up</h3><p className="xp2-muted">Businesses that join through your link are linked to you.</p></div>
          <div className="xp2-panel"><span className="xp2-num">3</span><h3>You earn</h3><p className="xp2-muted">You earn a share of their payments while they stay subscribed.</p></div>
        </div>
        <div className="xp2-panel">
          <h3>Programme terms</h3>
          <p className="xp-draft">Draft. The commission rate, payout schedule, payout method and referral window are confirmed before the programme opens.</p>
        </div>
        {user ? (
          <div className="xp2-panel">
            <h3>Your referral link</h3>
            <p className="xp2-muted">Anyone who signs up through this link is recorded as your referral.</p>
            <div className="xp-copy">
              <input value={referralUrl} readOnly onFocus={e => e.currentTarget.select()} />
              <button
                className="btn btn-lime btn-small"
                onClick={() => {
                  navigator.clipboard?.writeText(referralUrl);
                  setCopied(true);
                }}
              >
                {copied ? 'Copied' : 'Copy link'}
              </button>
            </div>
            <div className="xp-row">
              <button className="btn btn-ghost btn-small" onClick={() => window.open('https://wa.me/?text=' + encodeURIComponent(message), '_blank', 'noopener')}>Share on WhatsApp</button>
            </div>
            <p className="xp2-note">Referrals and earnings are not tracked yet, so nothing is recorded here until the programme is connected.</p>
          </div>
        ) : (
          <div className="xp2-panel xp-row">
            <div><h3>Ready to join?</h3><p className="xp2-muted">Create your free page first. Your referral link is ready once you sign in.</p></div>
            <button className="btn btn-lime btn-small" onClick={() => go('signup')}>Create my page</button>
          </div>
        )}
      </Section>
    </>
  );
}

function Changelog() {
  return (
    <>
      <Hero
        eyebrow="Changelog"
        title="What changed in"
        accent="this build."
        lead="A running record of what has been built and fixed."
        art={<StarCore />}
      />
      <Section>
        <div className="xp2-timeline">
          <div className="xp2-entry">
            <span className="xp2-dot" />
            <div className="xp2-panel">
              <h3>Unreleased</h3>
              <ul className="xp2-checklist">
                <li>Header menu button visible at all screen sizes</li>
                <li>Menu shows “Open dashboard” for signed-in users</li>
                <li>Dashboard layout adapts to tablets and phones</li>
                <li>Server ignores client-set plan, subscription and domain status</li>
              </ul>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}

function NotFound({ go }: { go: (v: string) => void }) {
  return (
    <section className="xp2-hero">
      <div className="xp2-copy">
        <div className="eyebrow"><Sparkles size={14} /> 404</div>
        <h1 className="xp2-title">This page <span>doesn't exist.</span></h1>
        <p className="xp2-lead">The link may be out of date, or the page may have moved.</p>
        <div className="xp-row">
          <button className="btn btn-lime" onClick={() => go('home')}>Go home</button>
          <button className="btn btn-ghost" onClick={() => go('templates')}>Browse templates</button>
        </div>
      </div>
      <div className="xp2-art">
        <Stage chips={[{ icon: <span className="xp2-q">?</span>, pos: 'c1' }]}>
          <StarCore dim />
        </Stage>
      </div>
    </section>
  );
}

export function ExtraPage({ view, go, onSignIn, onSignOut, user, plans, currency, onCurrencyChange, onSignUp, referralUrl, onSubscribe, subscriber }: Props) {
  let body: ReactNode;
  switch (view) {
    case 'templates': body = <Templates go={go} subscriber={subscriber} />; break;
    case 'examples': body = <Examples go={go} />; break;
    case 'analytics': body = <Analytics go={go} />; break;
    case 'billing': body = <Billing go={go} plans={plans} />; break;
    case 'settings': body = <Settings onSignOut={onSignOut} />; break;
    case 'login': body = <Login go={go} onSignIn={onSignIn} />; break;
    case 'signup': body = <Signup go={go} onSignUp={onSignUp} />; break;
    case 'onboarding': body = <Onboarding onSignIn={onSignIn} />; break;
    case 'help': body = <Help />; break;
    case 'contact': body = <Contact />; break;
    case 'pricing': body = <Pricing plans={plans} go={go} currency={currency} onCurrencyChange={onCurrencyChange} />; break;
    case 'terms': body = <Terms />; break;
    case 'privacy': body = <Legal kind="privacy" />; break;
    case 'changelog': body = <Changelog />; break;
    case 'notfound': body = <NotFound go={go} />; break;
    case 'affiliate': body = <Affiliate go={go} user={user} referralUrl={referralUrl} />; break;
  }
  return (
    <Frame go={go} user={user} onSignIn={onSignIn} onSignOut={onSignOut} onSubscribe={onSubscribe}>
      {body}
    </Frame>
  );
}
