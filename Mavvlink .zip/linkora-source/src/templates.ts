// Starter templates. Applying a template sets the accent colour and theme.
// Headline, bio, links and services are only filled in where the page is empty,
// so existing content is never overwritten.

export type TemplateTheme = 'dark' | 'light' | 'gradient' | 'minimal' | 'bold' | 'aurora';

export type TemplatePreset = {
  id: string;
  name: string;
  use: string;
  accent: string;
  theme: TemplateTheme;
  headline: string;
  bio: string;
  socials?: boolean;
  links: { title: string; url: string; kind: string }[];
  services: { title: string; description: string; price: string }[];
};

export const TEMPLATE_PRESETS: TemplatePreset[] = [
  {
    id: 'aurora',
    name: 'Aurora',
    use: 'Creators and personal brands',
    accent: '#d4a72c',
    theme: 'aurora',
    socials: true,
    headline: 'Full stack developer',
    bio: 'I build fast, clean websites and apps for businesses and creators.',
    links: [
      { title: 'Development portfolio', url: 'https://example.com/portfolio', kind: 'Website' },
      { title: 'Featured projects', url: 'https://example.com/projects', kind: 'Website' },
      { title: 'Tech stack', url: 'https://example.com/stack', kind: 'Website' },
      { title: 'Contact me', url: 'https://example.com/contact', kind: 'Website' },
    ],
    services: [
      { title: 'Full stack services', description: 'Design, build and launch.', price: 'Get a quote' },
    ],
  },
  {
    id: 'studio',
    name: 'Studio',
    use: 'Creatives and agencies',
    accent: '#9bf36b',
    theme: 'dark',
    socials: true,
    headline: 'Selected work and booking',
    bio: 'We design brands and websites that help small teams stand out.',
    links: [
      { title: 'See our work', url: 'https://example.com/work', kind: 'Website' },
      { title: 'Book a call', url: 'https://example.com/book', kind: 'Website' },
    ],
    services: [
      { title: 'Brand identity', description: 'Logo, colours and guidelines.', price: 'Get a quote' },
      { title: 'Website design', description: 'Fast, mobile-first sites.', price: 'Get a quote' },
    ],
  },
  {
    id: 'kitchen',
    name: 'Kitchen',
    use: 'Restaurants and food',
    accent: '#f7b267',
    theme: 'bold',
    headline: 'Menu, reservations and delivery',
    bio: 'Home-style food, made fresh every day.',
    links: [
      { title: "Today's menu", url: 'https://example.com/menu', kind: 'Website' },
      { title: 'Order on WhatsApp', url: 'https://wa.me/2348000000000', kind: 'WhatsApp' },
      { title: 'Find us', url: 'https://example.com/find-us', kind: 'Website' },
    ],
    services: [
      { title: 'Dine-in', description: 'Open for lunch and dinner.', price: '' },
      { title: 'Delivery', description: 'Within 5 km of the shop.', price: '' },
    ],
  },
  {
    id: 'consultant',
    name: 'Consultant',
    use: 'Coaches and advisors',
    accent: '#7aa7ff',
    theme: 'minimal',
    headline: 'Call booking and services',
    bio: 'Practical coaching for founders who want clear next steps.',
    links: [
      { title: 'Book a session', url: 'https://example.com/book', kind: 'Website' },
      { title: 'Free guide', url: 'https://example.com/guide', kind: 'Website' },
    ],
    services: [
      { title: 'One-to-one coaching', description: '60-minute session.', price: 'Get a quote' },
      { title: 'Business review', description: 'A written plan in one week.', price: 'Get a quote' },
    ],
  },
  {
    id: 'shop',
    name: 'Shop',
    use: 'Small stores',
    accent: '#ff8fab',
    theme: 'gradient',
    headline: 'Latest drops and checkout links',
    bio: 'Small-batch products, shipped across the country.',
    links: [
      { title: 'Shop new arrivals', url: 'https://example.com/shop', kind: 'Website' },
      { title: 'Chat to order', url: 'https://wa.me/2348000000000', kind: 'WhatsApp' },
    ],
    services: [
      { title: 'Nationwide delivery', description: 'Ships in 2 to 4 days.', price: '' },
    ],
  },
  {
    id: 'creator',
    name: 'Creator',
    use: 'Writers and video creators',
    accent: '#c69bff',
    theme: 'gradient',
    socials: true,
    headline: 'Newsletter, videos and sponsorships',
    bio: 'Stories and tutorials, every week.',
    links: [
      { title: 'Watch the latest video', url: 'https://example.com/video', kind: 'Website' },
      { title: 'Subscribe to the newsletter', url: 'https://example.com/newsletter', kind: 'Website' },
      { title: 'Work with me', url: 'https://example.com/sponsor', kind: 'Website' },
    ],
    services: [
      { title: 'Sponsored posts', description: 'Reach my audience.', price: 'Get a quote' },
    ],
  },
  {
    id: 'clinic',
    name: 'Clinic',
    use: 'Clinics and practitioners',
    accent: '#6fd3c1',
    theme: 'light',
    headline: 'Appointments and contact details',
    bio: 'Friendly, confidential care. Book an appointment online or call us.',
    links: [
      { title: 'Book an appointment', url: 'https://example.com/appointments', kind: 'Website' },
      { title: 'Call the clinic', url: 'tel:+2348000000000', kind: 'Website' },
    ],
    services: [
      { title: 'Consultation', description: 'Initial assessment.', price: 'Get a quote' },
    ],
  },
];
