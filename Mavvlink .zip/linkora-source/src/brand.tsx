import markWhite from './assets/mark-white.png';
import markDark from './assets/mark-dark.png';
import logoWhite from './assets/logo-white.png';
import logoDark from './assets/logo-dark.png';

// Shows the logo in the right ink for its background: white on the dark pages,
// black on the light dashboard. "mavvlink" stays as the accessible name.
export function BrandMark({ full = false }: { full?: boolean }) {
  return (
    <span className={full ? 'brand-logo brand-logo-full' : 'brand-logo brand-logo-mark'}>
      <img className="bl-on-dark" src={full ? logoWhite : markWhite} alt="mavvlink" />
      <img className="bl-on-light" src={full ? logoDark : markDark} alt="" aria-hidden="true" />
    </span>
  );
}

// Text logo used in the header and footer: the name "Mavvlink" set in the page font.
export function Wordmark({ size = 'header' }: { size?: 'header' | 'footer' }) {
  return <span className={'wordmark wordmark-' + size}>Mavvlink</span>;
}

