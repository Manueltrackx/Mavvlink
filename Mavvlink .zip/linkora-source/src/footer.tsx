import { useState, type FormEvent } from 'react';
import { ShieldCheck } from 'lucide-react';
import { Wordmark } from './brand';

type Link = { label: string; view?: string; hash?: string };

const COLUMNS: { title: string; links: Link[] }[] = [
  {
    title: 'Product',
    links: [
      { label: 'Features', hash: 'features' },
      { label: 'Templates', view: 'templates' },
      { label: 'Examples', view: 'examples' },
      { label: 'Pricing', view: 'pricing' },
      { label: 'Affiliate', view: 'affiliate' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About', view: 'about' },
      { label: 'Services', view: 'services-info' },
      { label: 'Contact', view: 'contact' },
      { label: 'Changelog', view: 'changelog' },
    ],
  },
  {
    title: 'Support',
    links: [
      { label: 'Help center', view: 'help' },
      { label: 'Terms', view: 'terms' },
      { label: 'Privacy', view: 'privacy' },
    ],
  },
];

type Props = {
  go: (view: string) => void;
  onStart: () => void;
  onLogin: () => void;
  signedIn: boolean;
  onSignOut: () => void;
  onSubscribe: (email: string) => Promise<string | null>;
};

// Shared site footer, used on every page.
export function SiteFooter({ go, signedIn, onSignOut, onSubscribe }: Props) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<{ kind: 'idle' | 'saving' | 'done' | 'error'; text: string }>({ kind: 'idle', text: '' });
  async function subscribe(e: FormEvent) {
    e.preventDefault();
    const address = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address)) {
      setStatus({ kind: 'error', text: 'Enter a valid email address.' });
      return;
    }
    setStatus({ kind: 'saving', text: 'Subscribing…' });
    const error = await onSubscribe(address);
    if (error) {
      setStatus({ kind: 'error', text: error });
    } else {
      setEmail('');
      setStatus({ kind: 'done', text: 'Thanks for subscribing.' });
    }
  }

  function open(link: Link) {
    if (link.hash) {
      go('home');
      setTimeout(() => document.getElementById(link.hash!)?.scrollIntoView({ behavior: 'smooth' }), 80);
    } else {
      go(link.view!);
    }
  }

  return (
    <footer className="sf">
      <div className="sf-inner">
        <div className="sf-top">
          <div className="sf-brand">
            <button className="sf-logo" onClick={() => go('home')} aria-label="mavvlink home">
              <Wordmark size="footer" />
            </button>
            <p>One beautiful link for everything you do. Build a page for your business in minutes.</p>
            <form className="sf-news" onSubmit={subscribe} noValidate>
              <label className="sf-news-label" htmlFor="sf-email">Get updates and tips by email</label>
              <div className="sf-news-row">
                <input
                  id="sf-email"
                  type="email"
                  value={email}
                  onChange={e => { setEmail(e.target.value); if (status.kind !== 'idle') setStatus({ kind: 'idle', text: '' }); }}
                  placeholder="Your email address"
                  autoComplete="email"
                />
                <button className="btn btn-lime btn-small" type="submit" disabled={status.kind === 'saving'}>Subscribe</button>
              </div>
              {status.text && <small className={'sf-news-msg ' + status.kind} role="status">{status.text}</small>}
            </form>
          </div>
          <nav className="sf-cols" aria-label="Footer">
            {COLUMNS.map(col => (
              <div className="sf-col" key={col.title}>
                <h4>{col.title}</h4>
                {col.links.map(link => (
                  <button key={link.label} onClick={() => open(link)}>{link.label}</button>
                ))}
              </div>
            ))}
          </nav>
        </div>
        <div className="sf-bottom">
          <span>© 2026 MAVVLINK. All rights reserved.</span>
          <div className="sf-legal">
            <button onClick={() => go('terms')}>Terms</button>
            <button onClick={() => go('privacy')}>Privacy</button>
            {signedIn && <button onClick={onSignOut}>Sign out</button>}
          </div>
        </div>
        <div className="sf-trust">
          <button className="sf-status" onClick={() => go('changelog')}>
            <span className="sf-dot" aria-hidden="true" />
            Platform status and updates
          </button>
          <span className="sf-shield">
            <ShieldCheck size={16} aria-hidden="true" />
            Your data is protected.
            <button onClick={() => go('privacy')}>Read our privacy policy</button>
          </span>
        </div>
      </div>
    </footer>
  );
}
