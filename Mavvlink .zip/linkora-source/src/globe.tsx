import { useEffect, useRef } from 'react';
import { CITIES, LAND } from './globe-data';

type V = [number, number, number];
const RAD = Math.PI / 180;
const GREEN = [155, 243, 107] as const;
const TILT = 18 * RAD; // view from slightly above the equator

function toXYZ(lon: number, lat: number): V {
  const la = lat * RAD;
  const lo = lon * RAD;
  return [Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo)];
}

// Rotate a point around the vertical axis (spin), then tilt it toward the viewer.
// Returns screen-space x, y in unit-sphere coordinates and the depth (z > 0 is the visible side).
function project(p: V, spin: number): [number, number, number] {
  const [x, y, z] = p;
  const x1 = x * Math.cos(spin) + z * Math.sin(spin);
  const z1 = -x * Math.sin(spin) + z * Math.cos(spin);
  const y2 = y * Math.cos(TILT) - z1 * Math.sin(TILT);
  const z2 = y * Math.sin(TILT) + z1 * Math.cos(TILT);
  return [x1, y2, z2];
}

function insidePolygon(pt: [number, number], poly: [number, number][]): boolean {
  const [x, y] = pt;
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

// Land dots: finer near the equator, fewer toward the poles so the spacing looks even.
const DOTS: V[] = (() => {
  const out: V[] = [];
  for (let lat = -80; lat <= 80; lat += 3.2) {
    const n = Math.max(10, Math.round((360 * Math.cos(lat * RAD)) / 3.2));
    for (let j = 0; j < n; j++) {
      const lon = -180 + (j * 360) / n;
      if (LAND.some(poly => insidePolygon([lon, lat], poly))) out.push(toXYZ(lon, lat));
    }
  }
  return out;
})();

// Arcs between pairs of cities, each with its own speed so the motion never lines up.
const ARCS = [
  [0, 2], [0, 4], [1, 4], [1, 10], [2, 12], [2, 3], [4, 5], [4, 9],
  [5, 6], [6, 7], [7, 10], [7, 8], [9, 11], [11, 4], [13, 6], [13, 7], [14, 5], [1, 13],
].map(([a, b], i) => ({ a, b, speed: 0.09 + ((i * 37) % 11) * 0.006, offset: (i * 0.23) % 1 }));

const CITY_V: V[] = CITIES.map(c => toXYZ(c.lon, c.lat));

function slerp(a: V, b: V, t: number): V {
  const dot = Math.max(-1, Math.min(1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2]));
  const omega = Math.acos(dot);
  if (omega < 1e-6) return a;
  const s1 = Math.sin((1 - t) * omega) / Math.sin(omega);
  const s2 = Math.sin(t * omega) / Math.sin(omega);
  return [s1 * a[0] + s2 * b[0], s1 * a[1] + s2 * b[1], s1 * a[2] + s2 * b[2]];
}

export function Globe() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    let raf = 0;
    let last = performance.now();
    let spin = -20 * RAD;
    let time = 0;
    let size = 0;
    let dpr = 1;

    function resize() {
      const css = canvas!.clientWidth;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      if (css === size) return;
      size = css;
      canvas!.width = Math.round(css * dpr);
      canvas!.height = Math.round(css * dpr);
    }

    function frame(now: number) {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      resize();
      if (!reduceMotion) {
        spin += dt * 9 * RAD; // about 40 seconds per turn
        time += dt;
      }
      const W = canvas!.width;
      const R = W * 0.44;
      const cx = W / 2;
      const cy = W / 2;
      ctx!.clearRect(0, 0, W, W);

      // Globe body with soft shading
      const body = ctx!.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R);
      body.addColorStop(0, 'rgba(34, 58, 36, 0.95)');
      body.addColorStop(0.7, 'rgba(12, 22, 14, 0.98)');
      body.addColorStop(1, 'rgba(6, 10, 7, 1)');
      ctx!.beginPath();
      ctx!.arc(cx, cy, R, 0, Math.PI * 2);
      ctx!.fillStyle = body;
      ctx!.fill();

      // Graticule (latitude and longitude lines) on the visible side
      ctx!.lineWidth = 0.6 * dpr;
      ctx!.strokeStyle = `rgba(${GREEN.join(',')}, 0.09)`;
      for (let lat = -60; lat <= 60; lat += 30) {
        ctx!.beginPath();
        let pen = false;
        for (let lon = -180; lon <= 180; lon += 4) {
          const [x, y, z] = project(toXYZ(lon, lat), spin);
          if (z > 0) {
            const px = cx + x * R, py = cy - y * R;
            pen ? ctx!.lineTo(px, py) : ctx!.moveTo(px, py);
            pen = true;
          } else pen = false;
        }
        ctx!.stroke();
      }
      for (let lon = -180; lon < 180; lon += 30) {
        ctx!.beginPath();
        let pen = false;
        for (let lat = -88; lat <= 88; lat += 4) {
          const [x, y, z] = project(toXYZ(lon, lat), spin);
          if (z > 0) {
            const px = cx + x * R, py = cy - y * R;
            pen ? ctx!.lineTo(px, py) : ctx!.moveTo(px, py);
            pen = true;
          } else pen = false;
        }
        ctx!.stroke();
      }

      // Land dots, brighter toward the centre of the visible side
      for (const d of DOTS) {
        const [x, y, z] = project(d, spin);
        if (z <= 0.02) continue;
        const alpha = 0.22 + 0.78 * z;
        ctx!.beginPath();
        ctx!.arc(cx + x * R, cy - y * R, (1.1 + 0.8 * z) * dpr, 0, Math.PI * 2);
        ctx!.fillStyle = `rgba(${GREEN.join(',')}, ${alpha.toFixed(3)})`;
        ctx!.fill();
      }

      // Arcs with a travelling pulse
      for (const arc of ARCS) {
        const A = CITY_V[arc.a], B = CITY_V[arc.b];
        const steps = 48;
        const head = (time * arc.speed + arc.offset) % 1;
        const trail = 0.28;
        for (let s = 0; s < steps; s++) {
          const t0 = s / steps, t1 = (s + 1) / steps;
          const tm = (t0 + t1) / 2;
          // Only draw the part of the arc that falls inside the trail behind the head
          const rel = (head - tm + 1) % 1;
          if (rel > trail) continue;
          const lift = 1 + 0.22 * Math.sin(Math.PI * t0);
          const p0 = slerp(A, B, t0).map(v => v * lift) as V;
          const p1 = slerp(A, B, t1).map(v => v * lift) as V;
          const [x0, y0, z0] = project(p0, spin);
          const [x1, y1, z1] = project(p1, spin);
          if (z0 <= 0 || z1 <= 0) continue;
          const fade = 1 - rel / trail;
          ctx!.beginPath();
          ctx!.moveTo(cx + x0 * R, cy - y0 * R);
          ctx!.lineTo(cx + x1 * R, cy - y1 * R);
          ctx!.strokeStyle = `rgba(${GREEN.join(',')}, ${(0.75 * fade).toFixed(3)})`;
          ctx!.lineWidth = (0.8 + 1.4 * fade) * dpr;
          ctx!.lineCap = 'round';
          ctx!.stroke();
        }
      }

      // City markers: a bright core with a pulsing ring
      CITY_V.forEach((c, i) => {
        const [x, y, z] = project(c, spin);
        if (z <= 0.05) return;
        const px = cx + x * R, py = cy - y * R;
        const phase = (time * 0.55 + i * 0.13) % 1;
        ctx!.beginPath();
        ctx!.arc(px, py, (2 + 13 * phase) * dpr, 0, Math.PI * 2);
        ctx!.strokeStyle = `rgba(${GREEN.join(',')}, ${(0.7 * (1 - phase) * z).toFixed(3)})`;
        ctx!.lineWidth = 1.2 * dpr;
        ctx!.stroke();
        ctx!.beginPath();
        ctx!.arc(px, py, 2.6 * dpr, 0, Math.PI * 2);
        ctx!.fillStyle = '#d9ffc2';
        ctx!.shadowColor = 'rgba(155, 243, 107, 0.9)';
        ctx!.shadowBlur = 8 * dpr;
        ctx!.fill();
        ctx!.shadowBlur = 0;
      });

      // Rim glow
      ctx!.beginPath();
      ctx!.arc(cx, cy, R, 0, Math.PI * 2);
      ctx!.strokeStyle = 'rgba(155, 243, 107, 0.28)';
      ctx!.lineWidth = 1.5 * dpr;
      ctx!.shadowColor = 'rgba(155, 243, 107, 0.5)';
      ctx!.shadowBlur = 18 * dpr;
      ctx!.stroke();
      ctx!.shadowBlur = 0;

      raf = requestAnimationFrame(frame);
    }

    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="globe-wrap">
      <canvas ref={canvasRef} role="img" aria-label="An animated globe with businesses connecting across the world" />
    </div>
  );
}
