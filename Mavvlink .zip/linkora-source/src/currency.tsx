// Display-only currency conversion for plan prices.
// Charges stay in NGN until a payment provider is connected.
//
// IMPORTANT: the rates below are PLACEHOLDERS. Replace them with your own
// rates before launch. Each rate is "how many units of this currency
// equal one naira".

export type CurrencyCode = 'NGN' | 'USD' | 'GBP' | 'EUR';

export const CURRENCIES: { code: CurrencyCode; label: string; locale: string; perNaira: number }[] = [
  { code: 'NGN', label: 'Nigerian naira', locale: 'en-NG', perNaira: 1 },
  { code: 'USD', label: 'US dollar', locale: 'en-US', perNaira: 0.00067 }, // PLACEHOLDER
  { code: 'GBP', label: 'British pound', locale: 'en-GB', perNaira: 0.00053 }, // PLACEHOLDER
  { code: 'EUR', label: 'Euro', locale: 'de-DE', perNaira: 0.00062 }, // PLACEHOLDER
];

// Country code -> currency. Any country not listed falls back to USD.
const COUNTRY_CURRENCY: Record<string, CurrencyCode> = {
  NG: 'NGN',
  US: 'USD',
  GB: 'GBP',
  DE: 'EUR', FR: 'EUR', IT: 'EUR', ES: 'EUR', NL: 'EUR', IE: 'EUR', PT: 'EUR', BE: 'EUR', AT: 'EUR',
};

export function detectCurrency(): CurrencyCode {
  try {
    const langs = navigator.languages?.length ? navigator.languages : [navigator.language];
    for (const lang of langs) {
      const match = /-([A-Za-z]{2})$/.exec(lang || '');
      if (match && COUNTRY_CURRENCY[match[1].toUpperCase()]) {
        return COUNTRY_CURRENCY[match[1].toUpperCase()];
      }
    }
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    if (tz === 'Africa/Lagos') return 'NGN';
    if (tz === 'Europe/London') return 'GBP';
    if (tz.startsWith('Europe/')) return 'EUR';
  } catch {
    // Browser does not expose language or timezone: use the default below.
  }
  return 'USD';
}

// ngn: the plan price in naira (the base amount).
export function formatPrice(ngn: number, code: CurrencyCode): string {
  const currency = CURRENCIES.find(c => c.code === code) ?? CURRENCIES[0];
  const amount = Math.round(ngn * currency.perNaira);
  return new Intl.NumberFormat(currency.locale, {
    style: 'currency',
    currency: currency.code,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function CurrencyPicker({ value, onChange }: { value: CurrencyCode; onChange: (c: CurrencyCode) => void }) {
  return (
    <div className="currency-picker">
      <label>
        <span>Show prices in</span>
        <select value={value} onChange={e => onChange(e.target.value as CurrencyCode)}>
          {CURRENCIES.map(c => (
            <option key={c.code} value={c.code}>
              {c.code} · {c.label}
            </option>
          ))}
        </select>
      </label>
      {value !== 'NGN' && <small>Indicative price. Checkout currency: NGN.</small>}
    </div>
  );
}
