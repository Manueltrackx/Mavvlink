import { useEffect, useRef, useState } from 'react';
import { Sparkles, X, ArrowUpRight } from 'lucide-react';
import { plans } from './plans';

type Msg = { role: 'user' | 'bot'; text: string; view?: string; label?: string; typed?: boolean };

// Each entry: keywords that trigger it, the answer, and an optional page to open.
type Entry = { keys: string[]; answer: () => string; view?: string; label?: string };

const planLine = () =>
  plans.map(p => `${p.name} ${p.price} (${p.note.toLowerCase()})`).join('; ') + '.';

const KB: Entry[] = [
  {
    keys: ['what', 'mavvlink', 'is', 'about', 'this', 'site', 'platform'],
    answer: () =>
      'mavvlink turns one link into a business page: your links, services, contact details and visitor numbers in one place. You can build yours in a few minutes.',
  },
  {
    keys: ['create', 'start', 'sign', 'signup', 'register', 'account', 'free', 'page', 'begin', 'join'],
    answer: () =>
      'Click "Create your free page". Enter your name, business name, email and page link, accept the terms, then sign in. Your page is set up after you sign in.',
    view: 'signup',
    label: 'Open sign up',
  },
  {
    keys: ['price', 'prices', 'cost', 'plan', 'plans', 'pricing', 'pay', 'payment', 'cheap', 'how', 'much', 'subscription'],
    answer: () =>
      `Plans: ${planLine()} Prices show in your currency. Online payments are not connected yet; checkout will be in naira.`,
    view: 'pricing',
    label: 'See pricing',
  },
  {
    keys: ['currency', 'naira', 'dollar', 'dollars', 'pounds', 'euro', 'convert', 'exchange'],
    answer: () =>
      'Use "Show prices in" on the pricing page to switch currency. Converted prices are indicative. Checkout is in naira.',
    view: 'pricing',
    label: 'Open pricing',
  },
  {
    keys: ['domain', 'custom', 'url', 'own', 'connect'],
    answer: () =>
      'Custom domains are on the Growth plan and above. Request one from the Custom domain page in your dashboard. Requests are reviewed before they go live.',
  },
  {
    keys: ['template', 'templates', 'theme', 'themes', 'look', 'design', 'style', 'colour', 'color'],
    answer: () =>
      'There are six starter templates: Studio, Kitchen, Consultant, Shop, Creator and Clinic. Pick one in the page builder. It sets the colours and theme, and fills in empty fields. Anything you have written is kept.',
    view: 'templates',
    label: 'Browse templates',
  },
  {
    keys: ['link', 'links', 'add', 'reorder', 'move', 'duplicate', 'builder', 'edit'],
    answer: () =>
      'In the page builder you can add links, move them up or down, and duplicate them. Only visible links appear on your public page.',
  },
  {
    keys: ['share', 'whatsapp', 'copy', 'backup', 'download', 'export', 'kit'],
    answer: () =>
      'The dashboard\'s Share kit shares your page on WhatsApp, copies your page link, and downloads a backup of your page as a JSON file.',
  },
  {
    keys: ['checklist', 'complete', 'missing', 'fix', 'progress'],
    answer: () =>
      'The dashboard overview has a page checklist of seven items. Each missing item has a Fix button that opens the right tab.',
  },
  {
    keys: ['affiliate', 'refer', 'referral', 'commission', 'earn', 'partner'],
    answer: () =>
      'The affiliate programme lets you earn by referring businesses. Your referral link is on the Affiliate page. The commission rate and payouts are still being finalised, and referral tracking is not connected yet.',
    view: 'affiliate',
    label: 'Open affiliate',
  },
  {
    keys: ['social', 'socials', 'instagram', 'tiktok', 'youtube', 'facebook', 'linkedin', 'twitter', 'icons', 'icon', 'media'],
    answer: () =>
      'Add your social profiles in the Social profiles section of the dashboard, then turn on Show icons. The Studio, Creator and Aurora templates show the icons by default. Icons only appear for the profiles you fill in.',
    view: 'dashboard',
    label: 'Open dashboard',
  },
  {
    keys: ['product', 'products', 'shop', 'sell', 'selling', 'store', 'catalogue', 'catalog', 'photo', 'photos'],
    answer: () =>
      'Add products in the Products section of the page builder. Upload a photo, enter the name, the link where customers buy and an optional price. They show as a grid on your public page, and each click is counted.',
    view: 'dashboard',
    label: 'Open dashboard',
  },
  {
    keys: ['analytics', 'stats', 'views', 'visitors', 'clicks', 'insights', 'numbers'],
    answer: () =>
      'The Analytics page shows views and clicks. The numbers in this preview are sample data. Real numbers appear once your page has visitors.',
    view: 'analytics',
    label: 'Open analytics',
  },
  {
    keys: ['newsletter', 'subscribe', 'email', 'updates', 'news', 'tips'],
    answer: () =>
      'Use the email box in the footer to subscribe for updates and tips. Sending emails is not connected yet.',
  },
  {
    keys: ['login', 'log', 'signin', 'sign'],
    answer: () =>
      'Use "Log in" at the top of the page. In this preview you sign in to a sample account.',
    view: 'login',
    label: 'Open log in',
  },
  {
    keys: ['cancel', 'cancellation', 'refund', 'terms', 'conditions'],
    answer: () =>
      'Plan details and cancellation terms are on the Pricing page. The terms are a draft and will be finalised before launch.',
    view: 'terms',
    label: 'Read terms',
  },
  {
    keys: ['privacy', 'data', 'protected', 'security', 'secure', 'safe', 'information'],
    answer: () =>
      'The privacy policy is a draft and needs review before launch. Once final, it will explain what data is collected and how it is used.',
    view: 'privacy',
    label: 'Read privacy policy',
  },
  {
    keys: ['contact', 'support', 'help', 'human', 'team', 'reach', 'message'],
    answer: () =>
      'Use the Contact page to send a message, or the Help center for common questions. This preview does not send messages yet.',
    view: 'contact',
    label: 'Open contact',
  },
  {
    keys: ['faq', 'questions', 'common', 'frequently'],
    answer: () => 'The Help center answers the common questions about publishing, links, domains, visitors and cancelling.',
    view: 'help',
    label: 'Open help center',
  },
  {
    keys: ['menu', 'navigate', 'navigation', 'find', 'pages', 'where'],
    answer: () =>
      'The menu button at the top right opens every page, grouped into Product, Company and Help. The footer links to them too.',
  },
  {
    keys: ['lead', 'leads', 'capture', 'form', 'enquiry', 'enquiries'],
    answer: () =>
      'Lead capture is listed on the Pro plan but is not built yet, so it is not available today.',
  },
  {
    keys: ['template', 'sample', 'demo', 'example', 'examples', 'preview'],
    answer: () =>
      'The Examples page shows example pages and a short recording of a real page. Each example is illustrative, not a live site.',
    view: 'examples',
    label: 'See examples',
  },
];

const GREETING = 'Hi, I am the mavvlink assistant. Ask me about pricing, templates, sign up, domains, links, sharing or the affiliate programme.';
const FALLBACK = 'I can only answer questions about this website. Try asking about pricing, templates, sign up, custom domains, links or the affiliate programme, or use the Contact page for anything else.';
const SUGGESTIONS = ['How do I create a page?', 'What does it cost?', 'Can I use my own domain?', 'How do templates work?', 'Is there an affiliate programme?'];

const STOP = new Set(['the', 'a', 'an', 'is', 'are', 'do', 'i', 'my', 'me', 'you', 'can', 'to', 'of', 'on', 'in', 'and', 'or', 'for', 'it', 'be', 'that', 'this', 'how', 'what', 'where', 'does', 'please', 'tell', 'about']);

export function answerFor(question: string): { text: string; view?: string; label?: string } {
  const q = question.toLowerCase();
  if (/^(hi|hello|hey|good (morning|afternoon|evening))\b/.test(q.trim())) return { text: GREETING };
  const words = q.replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(w => w && !STOP.has(w));
  let best: Entry | null = null;
  let bestScore = 0;
  for (const entry of KB) {
    const score = words.reduce((n, w) => n + (entry.keys.includes(w) ? 1 : 0), 0);
    if (score > bestScore) {
      best = entry;
      bestScore = score;
    }
  }
  if (!best || bestScore === 0) return { text: FALLBACK };
  return { text: best.answer(), view: best.view, label: best.label };
}

// Reveals text word by word for a typing effect.
function TypedText({ text, onDone }: { text: string; onDone?: () => void }) {
  const [count, setCount] = useState(0);
  const words = text.split(' ');
  useEffect(() => {
    if (count >= words.length) {
      onDone?.();
      return;
    }
    const t = window.setTimeout(() => setCount(c => c + 1), 28);
    return () => window.clearTimeout(t);
  }, [count, words.length, onDone]);
  return <>{words.slice(0, count).join(' ')}</>;
}

export function Agent() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([{ role: 'bot', text: GREETING, typed: true }]);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, thinking]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  function ask(question: string) {
    const q = question.trim();
    if (!q || thinking) return;
    setMessages(m => [...m, { role: 'user', text: q }]);
    setInput('');
    setThinking(true);
    window.setTimeout(() => {
      const reply = answerFor(q);
      setThinking(false);
      setMessages(m => [...m, { role: 'bot', text: reply.text, view: reply.view, label: reply.label }]);
    }, 650);
  }

  function markTyped(index: number) {
    setMessages(m => m.map((msg, i) => (i === index ? { ...msg, typed: true } : msg)));
  }

  function openPage(view: string) {
    window.dispatchEvent(new CustomEvent('mavvlink-go', { detail: view }));
    setOpen(false);
  }

  return (
    <>
      <button
        className={'ask-tab' + (open ? ' is-open' : '')}
        onClick={() => setOpen(o => !o)}
        aria-expanded={open}
        aria-controls="ask-panel"
      >
        <span className="ask-tab-spark"><Sparkles size={12} /></span>
        <span className="ask-tab-label">{open ? 'Close' : 'Ask mavvlink'}</span>
      </button>

      <div id="ask-panel" role="dialog" aria-label="Ask mavvlink" className={'ask-panel' + (open ? ' is-open' : '')}>
        <div className="ask-head">
          <div className="ask-title">
            <span className="ask-orb"><Sparkles size={13} /></span>
            <div>
              <b>mavvlink assistant</b>
              <small>Answers questions about this website</small>
            </div>
          </div>
          <button className="ask-close" onClick={() => setOpen(false)} aria-label="Close assistant"><X size={16} /></button>
        </div>

        <div className="ask-list" ref={listRef}>
          {messages.map((m, i) => (
            <div key={i} className={'ask-msg ' + m.role}>
              <p>
                {m.role === 'bot' && !m.typed ? <TypedText text={m.text} onDone={() => markTyped(i)} /> : m.text}
              </p>
              {m.role === 'bot' && m.typed && m.view && (
                <button className="ask-go" onClick={() => openPage(m.view!)}>
                  {m.label} <ArrowUpRight size={12} />
                </button>
              )}
            </div>
          ))}
          {thinking && (
            <div className="ask-msg bot">
              <p className="ask-dots"><span /><span /><span /></p>
            </div>
          )}
        </div>

        {messages.length <= 2 && (
          <div className="ask-chips">
            {SUGGESTIONS.map(s => (
              <button key={s} onClick={() => ask(s)} disabled={thinking}>{s}</button>
            ))}
          </div>
        )}

        <form
          className="ask-form"
          onSubmit={e => {
            e.preventDefault();
            ask(input);
          }}
        >
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Ask about pricing, templates, sign up…"
            aria-label="Your question"
            maxLength={300}
          />
          <button type="submit" disabled={!input.trim() || thinking} aria-label="Send question">
            <ArrowUpRight size={15} />
          </button>
        </form>
      </div>
    </>
  );
}
