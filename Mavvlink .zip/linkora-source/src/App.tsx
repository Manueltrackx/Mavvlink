import { useEffect, useMemo, useRef, useState } from 'react';
import { auth, api } from './appdeploy-client';
import {
  ArrowUpRight,
  BarChart3,
  Check,
  ChevronRight,
  CircleUserRound,
  ExternalLink,
  Globe2,
  LayoutDashboard,
  Link2,
  LogOut,
  Menu,
  MessageCircle,
  Plus,
  Rocket,
  Settings2,
  Sun,
  Moon,
  ShieldCheck,
  Sparkles,
  Store,
  Trash2,
  WandSparkles,
  X,
} from 'lucide-react';

import { ExtraPage, EXTRA_VIEWS, MENU_GROUPS, type ExtraView, type MenuItem } from './pages';
import { CurrencyPicker, detectCurrency, formatPrice, type CurrencyCode } from './currency';
import { TEMPLATE_PRESETS, type TemplatePreset } from './templates';
import { SOCIALS, SocialIcon, SocialMarquee, type SocialKey } from './social';
import { canUseCustomDomain, isSubscriber, productLimit, templateAllowed } from './access';
import { clearReferral, clearSignupDraft, readReferral, readSignupDraft, saveReferral, saveSignupDraft, type SignupDraft } from './signup';
import { BrandMark, Wordmark } from './brand';
import { SiteFooter } from './footer';
import { PhoneMockup } from './demo';
import { Globe } from './globe';
import { plans } from './plans';
import { Agent } from './agent';
import avatar1 from './assets/avatars/avatar-1.jpg';
import eyeImage from './assets/eye.gif';
import avatar2 from './assets/avatars/avatar-2.jpg';
import avatar3 from './assets/avatars/avatar-3.jpg';


const DESKTOP_NAV: MenuItem[] = [
  { label: 'Features', hash: 'features' },
  { label: 'Templates', view: 'templates' },
  { label: 'Pricing', view: 'pricing' },
  { label: 'Services', view: 'services-info' },
  { label: 'About', view: 'about' },
  { label: 'Help', view: 'help' },
];

type LinkItem = {
  id: string;
  title: string;
  url: string;
  kind: string;
  active: boolean;
};
type ProductItem = { id: string; title: string; url: string; price: string; image: string; imagePath?: string };
type Profile = {
  name: string;
  products?: ProductItem[];
  subscriptionStatus?: string;
  socials?: Partial<Record<SocialKey, string>>;
  showSocials?: boolean;
  slug: string;
  headline: string;
  bio: string;
  avatar: string;
  avatarPath?: string;
  backgroundType?: 'image' | 'video';
  backgroundUrl?: string;
  backgroundPath?: string;
  customDomain?: string;
  domainStatus?: string;
  expiresAt?: string;
  accent: string;
  theme: string;
  links: LinkItem[];
  services: { title: string; description: string; price: string }[];
  whatsapp: string;
  email: string;
  plan: string;
  views: number;
  referredBy?: string;
};
const blank: Profile = {
  name: 'Your Business',
  slug: 'your-business',
  headline: 'Everything you do, in one link.',
  bio: 'Tell people what you do and make it easy for them to take the next step.',
  avatar: '',
  accent: '#9bf36b',
  theme: 'dark',
  links: [
    {
      id: '1',
      title: 'Visit my website',
      url: 'https://example.com',
      kind: 'Website',
      active: true,
    },
    {
      id: '2',
      title: 'Chat on WhatsApp',
      url: 'https://wa.me/234',
      kind: 'WhatsApp',
      active: true,
    },
  ],
  services: [
    {
      title: 'Our services',
      description: 'A short introduction to what you offer.',
      price: 'Get a quote',
    },
  ],
  whatsapp: '',
  email: '',
  plan: 'Starter',
  views: 0,
};
function makeId() {
  return Math.random().toString(36).slice(2, 10);
}
function safeUrl(value: string) {
  return /^https?:\/\//i.test(value) ? value : 'https://' + value;
}

function AppInner() {
  const [user, setUser] = useState<any>(null);
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<Profile>(blank);
  const [view, setView] = useState<
    ExtraView | 'home' | 'about' | 'services-info' | 'dashboard' | 'edit' | 'services' | 'plans' | 'public' | 'domains' | 'admin'
  >('home');
  const [loading, setLoading] = useState(false);
  const [autoStatus, setAutoStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  // The last profile known to be saved on the server (loaded, or returned by a save).
  const autoBase = useRef<Profile | null>(null);
  const [notice, setNotice] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);
  const [fullPreview, setFullPreview] = useState(false);
  const [currency, setCurrency] = useState<CurrencyCode>(() => detectCurrency());
  const [isScrolled, setIsScrolled] = useState(false);
  const [publicSlug, setPublicSlug] = useState('');
  const [publicProfile, setPublicProfile] = useState<Profile | null>(null);
  const [tab, setTab] = useState('Overview');
  const [domain, setDomain] = useState('');
  const [socialPlatform, setSocialPlatform] = useState('Instagram');
  const [socialUrl, setSocialUrl] = useState('');
  const [backgroundBusy, setBackgroundBusy] = useState(false);
  const [adminData, setAdminData] = useState<any>(null);
  const [analytics, setAnalytics] = useState<any>(null);
  const [dashboardLight, setDashboardLight] = useState(() => window.localStorage.getItem('linkora-dashboard-theme') === 'light');
  function toggleDashboardTheme() { setDashboardLight(v => { const next = !v; window.localStorage.setItem('linkora-dashboard-theme', next ? 'light' : 'dark'); return next; }); }
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 24);
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (user && view === 'admin') api.get('/api/admin').then(r => setAdminData(r.data)).catch(() => setNotice('Owner access is restricted.'));
    if (user && view === 'dashboard') api.get('/api/analytics').then(r => setAnalytics(r.data)).catch(() => {});
  }, [user, view]);

  useEffect(() => {
    const ref = new URLSearchParams(window.location.search).get('ref');
    if (ref && /^[a-z0-9][a-z0-9-]{2,38}$/.test(ref)) saveReferral(ref);
    const hash = window.location.hash;
    const match = hash.match(/^#\/p\/([^/]+)/);
    if (match) {
      setPublicSlug(decodeURIComponent(match[1]));
      setView('public');
    }
    if (!match && hash.startsWith('#/')) setView('notfound');
    auth
      .getUser()
      .then(async u => {
        setUser(u);
        if (u) {
          let loaded: Profile | null = null;
          try {
            const res = await api.get('/api/site');
            if (res.data?.profile) {
              loaded = res.data.profile;
              autoBase.current = res.data.profile;
              setProfile(res.data.profile);
            }
          } catch {
            setNotice(
              'We could not load your workspace. Please refresh and try again.'
            );
          }
          // Sign-up details from the form: apply them to a brand-new account only.
          const draft = readSignupDraft();
          if (draft) {
            clearSignupDraft();
            if (loaded && loaded.name === 'Your Business' && loaded.links.length === 0) {
              const next: Profile = {
                ...loaded,
                name: draft.business,
                slug: draft.slug,
                email: draft.email,
                ...(draft.ref && draft.ref !== draft.slug ? { referredBy: draft.ref } : {}),
              };
              clearReferral();
              try {
                const saved = await api.put('/api/site', { profile: next });
                autoBase.current = saved.data?.profile ?? next;
                setProfile(saved.data?.profile ?? next);
                setNotice('Welcome! Your page is set up. Add your links and save.');
              } catch (e: any) {
                setProfile(next);
                setNotice(
                  e?.response?.data?.error ||
                    'We could not reserve that link. Choose another in the page builder, then save.'
                );
              }
            }
          }
          if (!match && !hash.startsWith('#/')) setView('dashboard');
        }
        setReady(true);
      })
      .catch(() => setReady(true));
  }, []);

  useEffect(() => {
    if (view === 'public' && publicSlug)
      api
        .get('/api/public/' + encodeURIComponent(publicSlug))
        .then(r => setPublicProfile(r.data.profile))
        .catch(() => setPublicProfile(null));
  }, [view, publicSlug]);

  const referralUrl = useMemo(() => {
    const origin = window.location.origin;
    const base = origin && origin !== 'null' ? origin + window.location.pathname : '';
    return base + '?ref=' + encodeURIComponent(profile.slug);
  }, [profile.slug]);
  useEffect(() => {
    // The AI agent asks the app to change page through this event.
    const go = (e: Event) => {
      setView((e as CustomEvent<string>).detail as any);
      window.scrollTo(0, 0);
    };
    window.addEventListener('mavvlink-go', go);
    return () => window.removeEventListener('mavvlink-go', go);
  }, []);
  useEffect(() => {
    // Sections fade up as they scroll into view. Runs again whenever the page changes.
    document.documentElement.classList.add('js');
    const selector = '.section, .split-section, .pricing-section, .cta-section, .demo-section, .logo-strip, .about-purpose, .about-values, .about-how, .about-cta, .services-intro, .services-grid, .services-bottom-cta, .xp2-section, .xp2-hero, .social-band-wrap';
    const targets = Array.from(document.querySelectorAll<HTMLElement>(selector));
    if (!('IntersectionObserver' in window)) {
      targets.forEach(el => el.classList.add('in'));
      return;
    }
    const io = new IntersectionObserver(
      entries =>
        entries.forEach(e => {
          if (e.isIntersecting) {
            e.target.classList.add('in');
            io.unobserve(e.target);
          }
        }),
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );
    targets.forEach(el => {
      el.classList.add('reveal');
      io.observe(el);
    });
    return () => io.disconnect();
  }, [view]);
  useEffect(() => {
    // Auto-save: once the user stops editing for 1.5 seconds, save the page.
    if (!user || !autoBase.current) return;
    if (profile === autoBase.current) return;
    const timer = window.setTimeout(async () => {
      if (!/^[a-z0-9][a-z0-9-]{2,38}$/.test(profile.slug)) {
        setAutoStatus('error');
        return;
      }
      const sent = profile;
      setAutoStatus('saving');
      try {
        const res = await api.put('/api/site', { profile: sent });
        autoBase.current = res.data.profile;
        // Only replace the page with the saved copy if nothing was typed during the save.
        setProfile(cur => (cur === sent ? res.data.profile : cur));
        setAutoStatus('saved');
      } catch {
        setAutoStatus('error');
      }
    }, 1500);
    return () => window.clearTimeout(timer);
  }, [profile, user]);
  useEffect(() => {
    // Messages clear themselves after 10 seconds.
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(''), 10000);
    return () => window.clearTimeout(timer);
  }, [notice]);
  const publicUrl = useMemo(
    () =>
      window.location.origin +
      window.location.pathname +
      '#/p/' +
      encodeURIComponent(profile.slug),
    [profile.slug]
  );
  async function uploadLogo(file: File) {
    if (file.size > 4 * 1024 * 1024) { setNotice('Choose an image smaller than 4 MB.'); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const data = String(reader.result).split(',')[1];
        const r = await api.post('/api/upload', { data, contentType: file.type });
        update('avatarPath' as keyof Profile, r.data.path as any);
        update('avatar', r.data.url as any);
        setNotice('Logo uploaded. Save your page to keep it.');
      } catch (e: any) { setNotice(e?.response?.data?.error || 'Upload failed.'); }
    };
    reader.readAsDataURL(file);
  }
  async function uploadBackground(file: File) {
    if (file.size > 15 * 1024 * 1024) { setNotice('Choose media smaller than 15 MB.'); return; }
    const allowed = ['image/png','image/jpeg','image/webp','video/mp4','video/webm'];
    if (!allowed.includes(file.type)) { setNotice('Use PNG, JPG, WEBP, MP4 or WEBM.'); return; }
    setBackgroundBusy(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const data = String(reader.result).split(',')[1];
        const r = await api.post('/api/background-upload', {data, contentType:file.type});
        update('backgroundPath' as keyof Profile, r.data.path as any);
        update('backgroundUrl' as keyof Profile, r.data.url as any);
        update('backgroundType' as keyof Profile, r.data.type as any);
        setNotice('Background uploaded. Save your page to keep it.');
      } catch (e:any) { setNotice(e?.response?.data?.error || 'Background upload failed.'); }
      finally { setBackgroundBusy(false); }
    };
    reader.readAsDataURL(file);
  }
  function addSocialLink() {
    const url = socialUrl.trim();
    if (!url) { setNotice('Enter your social profile URL first.'); return; }
    update('links', [...profile.links, {id:makeId(), title:socialPlatform, url:safeUrl(url), kind:socialPlatform, active:true}]);
    setSocialUrl('');
    setNotice(socialPlatform + ' link added to your page.');
  }
  async function requestDomain() {
    if (!canUseCustomDomain(profile)) { setNotice('Custom domains are available on the Growth plan and above.'); return; }
    try {
      const r = await api.post('/api/domain', { domain });
      setNotice('Domain request submitted: ' + r.data.domain + ' (pending review).');
      setDomain('');
      update('customDomain' as keyof Profile, r.data.domain as any);
      update('domainStatus' as keyof Profile, 'pending' as any);
    } catch (e: any) { setNotice(e?.response?.data?.error || 'Could not submit domain request.'); }
  }
  async function signIn() {
    setLoading(true);
    setNotice('');
    try {
      await auth.signInWithRedirect();
    } catch (e: any) {
      setNotice(e?.message || 'Sign-in could not start. Please try again.');
      setLoading(false);
    }
  }
  async function save() {
    setLoading(true);
    setNotice('');
    try {
      const res = await api.put('/api/site', { profile });
      autoBase.current = res.data.profile;
      setProfile(res.data.profile);
      setNotice('Your changes are saved.');
      return true;
    } catch (e: any) {
      setNotice(
        e?.response?.data?.error || e?.message || 'Could not save changes.'
      );
      return false;
    } finally {
      setLoading(false);
    }
  }
  async function publish() {
    const saved = await save();
    if (saved) setNotice('Your page is published. Share your link with customers.');
  }
  function previewCurrentPage() {
    setPublicSlug('');
    setPublicProfile({...profile});
    setView('public');
  }
  function update<K extends keyof Profile>(key: K, value: Profile[K]) {
    setProfile(p => ({ ...p, [key]: value }));
  }
  function addLink() {
    update('links', [
      ...profile.links,
      {
        id: makeId(),
        title: 'New link',
        url: 'https://',
        kind: 'Website',
        active: true,
      },
    ]);
  }
  function updateLink(id: string, key: keyof LinkItem, value: any) {
    update(
      'links',
      profile.links.map(l => (l.id === id ? { ...l, [key]: value } : l))
    );
  }
  function moveLink(id: string, dir: -1 | 1) {
    const i = profile.links.findIndex(l => l.id === id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= profile.links.length) return;
    const next = [...profile.links];
    [next[i], next[j]] = [next[j], next[i]];
    update('links', next);
  }
  function duplicateLink(id: string) {
    const i = profile.links.findIndex(l => l.id === id);
    if (i < 0) return;
    const copy = { ...profile.links[i], id: makeId(), title: profile.links[i].title + ' (copy)' };
    const next = [...profile.links];
    next.splice(i + 1, 0, copy);
    update('links', next);
  }
  const pageChecklist = [
    { label: 'Business name', done: !!profile.name.trim() && profile.name !== 'Your Business', tab: 'edit' },
    { label: 'Headline', done: !!profile.headline.trim(), tab: 'edit' },
    { label: 'Short bio (at least 20 characters)', done: profile.bio.trim().length >= 20, tab: 'edit' },
    { label: 'Profile photo or logo', done: !!(profile.avatar || profile.avatarPath), tab: 'edit' },
    { label: 'At least one visible link', done: profile.links.some(l => l.active), tab: 'edit' },
    { label: 'At least one service', done: profile.services.length > 0, tab: 'services' },
    { label: 'A way to contact you (WhatsApp or email)', done: !!(profile.whatsapp.trim() || profile.email.trim()), tab: 'edit' },
  ];
  const checklistDone = pageChecklist.filter(c => c.done).length;
  function shareOnWhatsApp() {
    const text = `Find ${profile.name} here: ${publicUrl}`;
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
  }
  function downloadBackup() {
    const blob = new Blob([JSON.stringify(profile, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${profile.slug || 'mavvlink'}-backup.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function applyTemplate(t: TemplatePreset) {
    if (!templateAllowed(t.id, profile)) {
      setNotice(`${t.name} is for subscribers. Free accounts can use Studio and Consultant.`);
      return;
    }
    setProfile(p => ({
      ...p,
      accent: t.accent,
      theme: t.theme,
      showSocials: t.socials ?? false,
      headline: p.headline.trim() ? p.headline : t.headline,
      bio: p.bio.trim() ? p.bio : t.bio,
      links: p.links.length ? p.links : t.links.map(l => ({ ...l, id: makeId(), active: true })),
      services: p.services.length ? p.services : t.services,
    }));
    setNotice(`${t.name} template applied. Review it, then save your page.`);
  }
  function setProducts(next: (list: ProductItem[]) => ProductItem[]) {
    setProfile(p => ({ ...p, products: next(p.products ?? []) }));
  }
  function addProduct() {
    const limit = productLimit(profile);
    setProducts(list => (list.length >= limit ? list : [...list, { id: makeId(), title: '', url: '', price: '', image: '' }]));
  }
  function patchProduct(id: string, patch: Partial<ProductItem>) {
    setProducts(list => list.map(x => (x.id === id ? { ...x, ...patch } : x)));
  }
  function moveProduct(i: number, dir: -1 | 1) {
    setProducts(list => {
      const j = i + dir;
      if (j < 0 || j >= list.length) return list;
      const copy = [...list];
      [copy[i], copy[j]] = [copy[j], copy[i]];
      return copy;
    });
  }
  function removeProduct(id: string) {
    setProducts(list => list.filter(x => x.id !== id));
  }
  async function uploadProductImage(id: string, file: File) {
    if (file.size > 4 * 1024 * 1024) { setNotice('Choose an image smaller than 4 MB.'); return; }
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) { setNotice('Use PNG, JPG or WEBP.'); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const data = String(reader.result).split(',')[1];
        const r = await api.post('/api/upload', { data, contentType: file.type });
        patchProduct(id, { image: r.data.url, imagePath: r.data.path });
        setNotice('Product image uploaded. Save your page to keep it.');
      } catch (e: any) { setNotice(e?.response?.data?.error || 'Upload failed.'); }
    };
    reader.readAsDataURL(file);
  }
  function addService() {
    update('services', [
      ...profile.services,
      {
        title: 'New service',
        description: 'Describe this service.',
        price: 'Contact us',
      },
    ]);
  }

  if (!ready)
    return (
      <div className="loading-screen">
        <BrandMark />
        <span>Preparing your workspace…</span>
      </div>
    );
  function goMenu(item: MenuItem) {
    setMobileMenu(false);
    if (item.hash) {
      setView('home');
      setTimeout(() => document.getElementById(item.hash!)?.scrollIntoView({ behavior: 'smooth' }), 80);
      return;
    }
    setView(item.view as any);
    window.scrollTo(0, 0);
  }

  function goView(v: string) {
    setView(v as any);
    window.scrollTo(0, 0);
  }
  async function subscribeNewsletter(email: string): Promise<string | null> {
    try {
      await api.post('/api/newsletter', { email });
      return null;
    } catch (e: any) {
      return e?.response?.data?.error || "We couldn't subscribe you right now. Please try again later.";
    }
  }
  async function handleSignOut() {
    await auth.signOut();
    setUser(null);
    setView('home');
  }
  function goSignup() {
    setView('signup');
    window.scrollTo(0, 0);
  }
  function handleSignUp(d: SignupDraft) {
    saveSignupDraft({ ...d, ref: readReferral() ?? undefined });
    signIn();
  }

  if (EXTRA_VIEWS.includes(view as ExtraView))
    return (
      <ExtraPage
        view={view as ExtraView}
        go={v => { setView(v as any); window.scrollTo(0, 0); }}
        onSignIn={signIn}
        onSignUp={handleSignUp}
        referralUrl={referralUrl}
        subscriber={isSubscriber(profile)}
        onSubscribe={subscribeNewsletter}
        onSignOut={async () => { await auth.signOut(); setUser(null); setView('home'); }}
        user={user}
        plans={plans}
        currency={currency}
        onCurrencyChange={setCurrency}
      />
    );
  if (view === 'public') return <PublicPage profile={publicProfile} onBack={publicSlug ? undefined : () => setView('edit')} />;
  return (
    <div className={"app-shell" + (dashboardLight ? " dashboard-light" : "")}>
      <div className="site-header-shell">
      <header className={"topbar" + (isScrolled ? " topbar-scrolled" : "")}>
        <a
          className="brand"
          href="#"
          onClick={e => {
            e.preventDefault();
            setView(user ? 'dashboard' : 'home');
          }}
        >
          <Wordmark />
        </a>
        <nav className="desktop-nav">
          {DESKTOP_NAV.map(item => (
            <button key={item.label} className="nav-text-button" onClick={() => goMenu(item)}>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="top-actions">
          {user && <button className="theme-toggle dashboard-theme-toggle" onClick={toggleDashboardTheme} aria-label={dashboardLight ? "Switch dashboard to dark mode" : "Switch dashboard to light mode"} title={dashboardLight ? "Dark mode" : "Light mode"}>{dashboardLight ? <Moon size={16}/> : <Sun size={16}/>}</button>}
          {user ? (
            <button
              className="btn btn-dark btn-small"
              onClick={() => setView('dashboard')}
            >
              Open dashboard <ArrowUpRight size={15} />
            </button>
          ) : (
            <>
              <button className="btn btn-ghost btn-small" onClick={signIn}>
                Log in
              </button>
              <button className="btn btn-dark btn-small" onClick={goSignup}>
                Get started <ArrowUpRight size={15} />
              </button>
            </>
          )}
        </div>
        <button
          className="menu-toggle"
          onClick={() => setMobileMenu(!mobileMenu)}
          aria-label={mobileMenu ? 'Close menu' : 'Open menu'}
          aria-expanded={mobileMenu}
        >
          {mobileMenu ? <X /> : <Menu />}
        </button>
      </header>
      {mobileMenu && (
        <div className="mobile-menu">
          {MENU_GROUPS.map(group => {
            const open = openGroup === group.label;
            return (
              <div className="menu-group" key={group.label}>
                <button
                  className="menu-group-toggle"
                  aria-expanded={open}
                  onClick={() => setOpenGroup(open ? null : group.label)}
                >
                  <span>{group.label}</span>
                  <ChevronRight size={16} className={open ? 'menu-chev open' : 'menu-chev'} />
                </button>
                {open &&
                  group.items.map(item => (
                    <button key={item.label} className="menu-item" onClick={() => goMenu(item)}>
                      {item.label} <ChevronRight size={16} />
                    </button>
                  ))}
              </div>
            );
          })}
          <div className="menu-group">
            <div className="menu-group-label">Account</div>
            <div className="menu-actions">
              {user ? (
                <>
                  <button className="btn btn-dark" onClick={() => { setView('dashboard'); setMobileMenu(false); }}>
                    Open dashboard
                  </button>
                  <button className="btn btn-ghost" onClick={async () => { await auth.signOut(); setUser(null); setView('home'); setMobileMenu(false); }}>
                    Sign out
                  </button>
                </>
              ) : (
                <>
                  <button className="btn btn-ghost" onClick={signIn}>Log in</button>
                  <button className="btn btn-dark" onClick={goSignup}>Get started</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
      </div>
      {notice && (
        <div className="notice">
          <span>{notice}</span>
          <button onClick={() => setNotice('')}>
            <X size={15} />
          </button>
        </div>
      )}
      {view === 'about' && (
        <AboutPage
          onGetStarted={goSignup}
          go={goView}
          onLogin={signIn}
          signedIn={!!user}
          onSignOut={handleSignOut}
          onSubscribe={subscribeNewsletter}
        />
      )}
      {view === 'services-info' && <ServicesPage onGetStarted={goSignup} />}
      {view === 'home' && (
        <main>
          <section className="hero wrap">
            <div className="hero-copy">
              <div className="eyebrow">
                <Sparkles size={14} /> THE BUSINESS LINK PLATFORM
              </div>
              <h1>
                Your whole business.
                <br />
                <span>One beautiful link.</span>
              </h1>
              <p className="hero-lead">
                Turn your bio link into a business-ready mini website. Share
                what you do, showcase your services, collect enquiries and grow
                — all from one simple page.
              </p>
              <div className="hero-buttons">
                <button className="btn btn-lime" onClick={goSignup}>
                  Create your free page <ArrowUpRight size={17} />
                </button>
                <a className="text-link" href="#features">
                  Explore the platform <ChevronRight size={16} />
                </a>
              </div>
              <div className="social-proof">
                <div className="avatar-stack">
                  <i><img src={avatar1} alt="" /></i>
                  <i><img src={avatar2} alt="" /></i>
                  <i><img src={avatar3} alt="" /></i>
                  <i>+</i>
                </div>
                <span>Made for ambitious businesses and creators</span>
              </div>
            </div>
            <div className="hero-visual">
              <Globe />
            </div>
          </section>
          <section className="logo-strip wrap">
            <span>ONE LINK FOR EVERY PART OF YOUR BUSINESS</span>
            <div>
              <b>CREATORS</b>
              <b>SMALL BUSINESS</b>
              <b>AGENCIES</b>
              <b>PERSONAL BRANDS</b>
              <b>ONLINE STORES</b>
            </div>
          </section>
          <div className="wrap social-band-wrap">
            <SocialMarquee />
          </div>
          <section className="section wrap" id="features">
            <div className="section-heading">
              <div className="eyebrow">MORE THAN A BIO LINK</div>
              <h2>
                Your digital front door,
                <br />
                <span>without the complexity.</span>
              </h2>
              <p>
                Everything customers need to discover you, trust you and take
                action — neatly organised in one place.
              </p>
            </div>
            <div className="feature-grid">
              <article className="feature-card feature-dark">
                <div className="feature-icon">
                  <LayoutDashboard />
                </div>
                <h3>A page that feels like you.</h3>
                <p>
                  Choose a look, add your brand details and publish a polished
                  mini website in minutes.
                </p>
                <div className="mini-window">
                  <div className="mini-window-top">
                    <i></i>
                    <i></i>
                    <i></i>
                  </div>
                  <div className="mini-window-content">
                    <div className="mini-avatar"></div>
                    <div className="mini-line"></div>
                    <div className="mini-line short"></div>
                    <div className="mini-button"></div>
                    <div className="mini-button"></div>
                  </div>
                </div>
              </article>
              <article className="feature-card">
                <div className="feature-icon">
                  <Store />
                </div>
                <h3>Showcase what you offer.</h3>
                <p>
                  Highlight products, services, prices and portfolio links so
                  visitors know exactly how to work with you.
                </p>
                <div className="service-preview">
                  <div>
                    <span>01</span>
                    <b>Brand strategy</b>
                    <small>From ₦25,000</small>
                  </div>
                  <div>
                    <span>02</span>
                    <b>Web design</b>
                    <small>Request a quote</small>
                  </div>
                </div>
              </article>
              <article className="feature-card">
                <div className="feature-icon">
                  <BarChart3 />
                </div>
                <h3>Understand your audience.</h3>
                <p>
                  See page visits and learn which parts of your page are getting
                  attention.
                </p>
                <div className="chart-preview">
                  <div className="chart-bars">
                    <i />
                    <i />
                    <i />
                    <i />
                    <i />
                    <i />
                    <i />
                    <i />
                  </div>
                  <div className="chart-caption">
                    <b>Engagement</b>
                    <span>Last 7 days</span>
                  </div>
                </div>
              </article>
            </div>
          </section>
          <section className="demo-section wrap" id="demo">
            <div className="demo-copy">
              <div className="eyebrow">SEE IT IN ACTION</div>
              <h2>A real page, built with mavvlink.</h2>
              <p>Links, services and a clear way to get in touch, all on one page your customers can open from anywhere.</p>
              <div className="demo-actions">
                <button className="btn btn-lime" onClick={goSignup}>
                  Create your free page <ArrowUpRight size={17} />
                </button>
              </div>
            </div>
            <div className="demo-phone">
              <PhoneMockup />
            </div>
          </section>

          <section className="split-section wrap" id="templates">
            <div>
              <div className="eyebrow">SIMPLE BY DESIGN</div>
              <h2>
                Set up in minutes.
                <br />
                <span>Not another project.</span>
              </h2>
              <p>
                Start with the essentials. Add your name, links, services and
                contact details. Your page is ready to share — no code, no
                complicated setup.
              </p>
              <button className="btn btn-dark" onClick={goSignup}>
                Build your page <ArrowUpRight size={16} />
              </button>
            </div>
            <div className="steps-card">
              <div className="step">
                <span>01</span>
                <div>
                  <b>Create your account</b>
                  <p>Sign in and claim your page name.</p>
                </div>
                <Check />
              </div>
              <div className="step">
                <span>02</span>
                <div>
                  <b>Make it yours</b>
                  <p>Add your links, services and brand style.</p>
                </div>
                <Check />
              </div>
              <div className="step">
                <span>03</span>
                <div>
                  <b>Publish and share</b>
                  <p>Get one simple link for your audience.</p>
                </div>
                <Rocket />
              </div>
            </div>
          </section>
          <section className="pricing-section" id="pricing">
            <div className="wrap">
              <div className="section-heading centered">
                <div className="eyebrow">CLEAR, SIMPLE PLANS</div>
                <h2>
                  Start free. <span>Grow when ready.</span>
                </h2>
                <p>
                  Pick the tools you need today. Upgrade as your business grows.
                </p>
              </div>
              <CurrencyPicker value={currency} onChange={setCurrency} />
              <div className="pricing-grid">
                {plans.map((p, i) => (
                  <div
                    className={'price-card ' + (i === 1 ? 'popular' : '')}
                    key={p.name}
                  >
                    {i === 1 && (
                      <div className="popular-label">MOST POPULAR</div>
                    )}
                    <h3>{p.name}</h3>
                    <p>{p.note}</p>
                    <div className="price">
                      {formatPrice(p.ngn, currency)}
                      <small>{i === 0 ? '' : ' / month'}</small>
                    </div>
                    <button
                      className={i === 1 ? 'btn btn-lime' : 'btn btn-outline'}
                      onClick={goSignup}
                    >
                      Choose {p.name} <ArrowUpRight size={15} />
                    </button>
                    <ul>
                      {p.features.map(f => (
                        <li key={f}>
                          <Check size={15} />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
              <p className="billing-note">
                Subscription checkout is the next billing setup step; plan
                selection is shown here so you can choose your business tier.
              </p>
            </div>
          </section>
          <section className="cta-section wrap">
            <div>
              <div className="eyebrow">READY WHEN YOU ARE</div>
              <h2>
                Make every click
                <br />
                count.
              </h2>
              <p>Your business deserves more than a list of links.</p>
              <button className="btn btn-lime" onClick={goSignup}>
                Create your free page <ArrowUpRight size={17} />
              </button>
            </div>
            <div className="cta-orb">
              <Link2 size={84} />
            </div>
          </section>
        </main>
      )}
      {user && view !== 'home' && view !== 'about' && view !== 'services-info' && (
        <div className="dashboard-layout">
          <aside className="sidebar">
            <div className="side-label">WORKSPACE</div>
            <button
              className={
                view === 'dashboard' ? 'side-item active' : 'side-item'
              }
              onClick={() => setView('dashboard')}
            >
              <LayoutDashboard size={17} /> Overview
            </button>
            <button
              className={view === 'edit' ? 'side-item active' : 'side-item'}
              onClick={() => setView('edit')}
            >
              <WandSparkles size={17} /> Page builder
            </button>
            <button
              className={view === 'services' ? 'side-item active' : 'side-item'}
              onClick={() => setView('services')}
            >
              <Store size={17} /> Services
            </button>
            <button className={view === 'domains' ? 'side-item active' : 'side-item'} onClick={() => setView('domains')}><Globe2 size={17} /> Custom domain</button>
            <button className={view === 'affiliate' ? 'side-item active' : 'side-item'} onClick={() => setView('affiliate')}><Link2 size={17} /> Affiliate</button>
            {user.email?.toLowerCase() === 'mcinterydwayne@gmail.com' && <button className={view === 'admin' ? 'side-item active' : 'side-item'} onClick={() => setView('admin')}><ShieldCheck size={17} /> Owner admin</button>}
            <button
              className={view === 'plans' ? 'side-item active' : 'side-item'}
              onClick={() => setView('plans')}
            >
              <Sparkles size={17} /> Plans & billing
            </button>
            <div className="sidebar-bottom">
              <div className="side-label">ACCOUNT</div>
              <button
                className="side-item"
                onClick={async () => {
                  await auth.signOut();
                  setUser(null);
                  setView('home');
                }}
              >
                <LogOut size={17} /> Sign out
              </button>
              <div className="account-chip">
                <div className="account-avatar">
                  <CircleUserRound />
                </div>
                <div>
                  <b>{user.name || 'Your account'}</b>
                  <small>{user.email || 'Signed in'}</small>
                </div>
              </div>
            </div>
          </aside>
          <div className="dashboard-main">
            <div className="dash-top">
              <div>
                <div className="eyebrow">YOUR WORKSPACE</div>
                <h1>
                  {view === 'dashboard'
                    ? 'Welcome back'
                    : view === 'edit'
                      ? 'Page builder'
                      : view === 'services'
                        ? 'Your services'
                        : view === 'domains' ? 'Custom domain' : view === 'admin' ? 'Owner administration' : 'Plans & billing'}
                </h1>
              </div>
              <div className="dash-top-actions">
                {autoStatus !== 'idle' && (
                  <span className={'autosave ' + autoStatus} role="status">
                    {autoStatus === 'saving' && 'Saving…'}
                    {autoStatus === 'saved' && 'All changes saved'}
                    {autoStatus === 'error' && 'Not saved yet. Check your page link.'}
                  </span>
                )}
                <button className="preview-link" onClick={previewCurrentPage}>
                  <ExternalLink size={15} /> Preview page
                </button>
                <button className="btn btn-dark btn-small" onClick={publish}>
                  Publish changes <ArrowUpRight size={15} />
                </button>
              </div>
            </div>
            {notice && (
              <div className="notice inline-notice">
                {notice}
                <button onClick={() => setNotice('')}>
                  <X size={15} />
                </button>
              </div>
            )}
            {view === 'dashboard' && (
              <>
                <div className="welcome-panel">
                  <div>
                    <div className="eyebrow">YOUR BUSINESS, IN ONE PLACE</div>
                    <h2>
                      Make your first impression
                      <br />a great one.
                    </h2>
                    <p>Complete your page and share it with your audience.</p>
                    <button
                      className="btn btn-lime"
                      onClick={() => setView('edit')}
                    >
                      Customise my page <ChevronRight size={16} />
                    </button>
                  </div>
                  <div className="welcome-art">
                    <div className="welcome-ring">
                      <Link2 size={54} />
                    </div>
                  </div>
                </div>
                <div className="dash-two">
                  <div className="panel">
                    <div className="panel-head"><h3>Page checklist</h3><span>{checklistDone} OF {pageChecklist.length}</span></div>
                    <ul className="check-list">
                      {pageChecklist.map(item => (
                        <li key={item.label} className={item.done ? 'done' : ''}>
                          <span className="check-dot">{item.done && <Check size={13} />}</span>
                          <span className="check-label">{item.label}</span>
                          {!item.done && (
                            <button className="btn btn-ghost btn-small" onClick={() => setView(item.tab as any)}>Fix</button>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="panel">
                    <div className="panel-head"><h3>Share kit</h3><span>QUICK</span></div>
                    <p className="muted">Send your page to customers in one tap.</p>
                    <div className="share-kit">
                      <button className="btn btn-dark btn-small" onClick={shareOnWhatsApp}>Share on WhatsApp</button>
                      <button className="btn btn-ghost btn-small" onClick={() => navigator.clipboard?.writeText(publicUrl)}>Copy page link</button>
                      <button className="btn btn-ghost btn-small" onClick={downloadBackup}>Download backup (JSON)</button>
                    </div>
                  </div>
                </div>
                <div className="stats-grid">
                  <div className="stat-card">
                    <span>TRACKED LINK CLICKS</span>
                    <b>{analytics?.clicks || 0}</b>
                    <small>Recorded on public pages</small>
                  </div>
                  <div className="stat-card">
                    <span>PAGE VISITS</span>
                    <b>{profile.views || 0}</b>
                    <small>Since your page went live</small>
                  </div>
                  <div className="stat-card">
                    <span>ACTIVE LINKS</span>
                    <b>{profile.links.filter(l => l.active).length}</b>
                    <small>Links on your page</small>
                  </div>
                  <div className="stat-card">
                    <span>PLAN</span>
                    <b>{profile.plan}</b>
                    <small>Current workspace tier</small>
                  </div>
                </div>
                <div className="dash-bottom-grid">
                  <div className="panel">
                    <div className="panel-head">
                      <h3>Quick actions</h3>
                      <span>GET STARTED</span>
                    </div>
                    <button
                      className="action-row"
                      onClick={() => setView('edit')}
                    >
                      <span className="action-icon">
                        <WandSparkles />
                      </span>
                      <span>
                        <b>Customise your page</b>
                        <small>Set your profile, links and style</small>
                      </span>
                      <ChevronRight />
                    </button>
                    <button
                      className="action-row"
                      onClick={() => setView('services')}
                    >
                      <span className="action-icon">
                        <Store />
                      </span>
                      <span>
                        <b>Add a service</b>
                        <small>Show customers what you offer</small>
                      </span>
                      <ChevronRight />
                    </button>
                    <button
                      className="action-row"
                      onClick={() =>
                        navigator.clipboard
                          ?.writeText(publicUrl)
                          .then(() => setNotice('Page link copied.'))
                      }
                    >
                      <span className="action-icon">
                        <Link2 />
                      </span>
                      <span>
                        <b>Copy your page link</b>
                        <small>{publicUrl}</small>
                      </span>
                      <ChevronRight />
                    </button>
                  </div>
                  <div className="panel page-status">
                    <div className="panel-head">
                      <h3>Your page</h3>
                      <span className="status-pill">
                        <i /> READY TO EDIT
                      </span>
                    </div>
                    <div className="page-mini">
                      <div className="page-mini-avatar">
                        {profile.name.slice(0, 1).toUpperCase()}
                      </div>
                      <b>{profile.name}</b>
                      <span>{profile.headline}</span>
                      <div className="page-mini-link">
                        Your website <ArrowUpRight size={13} />
                      </div>
                    </div>
                    <button
                      className="btn btn-outline full"
                      onClick={() => setView('edit')}
                    >
                      Edit page <ArrowUpRight size={15} />
                    </button>
                  </div>
                </div>
              </>
            )}
            {view === 'edit' && (
              <div className="editor-grid">
                <div className="editor-column">
                  <div className="panel">
                    <div className="panel-head">
                      <h3>Profile details</h3>
                      <span>01 / IDENTITY</span>
                    </div>
                    <label>
                      Business or creator name
                      <input
                        value={profile.name}
                        onChange={e => update('name', e.target.value)}
                        placeholder="Your name"
                      />
                    </label>
                    <label>
                      Page username
                      <input
                        value={profile.slug}
                        onChange={e =>
                          update(
                            'slug',
                            e.target.value
                              .toLowerCase()
                              .replace(/[^a-z0-9-]/g, '')
                          )
                        }
                        placeholder="your-name"
                      />
                    </label>
                    <label>
                      Headline
                      <input
                        value={profile.headline}
                        onChange={e => update('headline', e.target.value)}
                        placeholder="What do you do?"
                      />
                    </label>
                    <label>
                      Short bio
                      <textarea
                        value={profile.bio}
                        onChange={e => update('bio', e.target.value)}
                        rows={3}
                      />
                    </label>
                    <div className="public-url">
                      <Globe2 size={15} />
                      <span>{publicUrl}</span>
                      <button
                        onClick={() =>
                          navigator.clipboard
                            ?.writeText(publicUrl)
                            .then(() => setNotice('Page link copied.'))
                        }
                      >
                        Copy
                      </button>
                    </div>
                  </div>
                  <div className="panel">
                    <div className="panel-head">
                      <div>
                        <h3>Your links</h3>
                        <p className="muted">Add websites, social profiles, booking pages and more.</p>
                      </div>
                      <button className="btn btn-dark btn-small" onClick={addLink}>
                        <Plus size={15} /> Add link
                      </button>
                    </div>
                    {profile.links.map(link => (
                      <div className="link-editor-row" key={link.id}>
                        <div className="link-editor-fields">
                          <label>
                            Button title
                            <input
                              value={link.title}
                              onChange={e => updateLink(link.id, 'title', e.target.value)}
                              placeholder="e.g. Visit our website"
                            />
                          </label>
                          <label>
                            Destination URL
                            <input
                              value={link.url}
                              onChange={e => updateLink(link.id, 'url', e.target.value)}
                              placeholder="https://example.com"
                            />
                          </label>
                        </div>
                        <div className="link-editor-controls">
                          <button
                            className="icon-btn"
                            aria-label="Move link up"
                            disabled={profile.links.indexOf(link) === 0}
                            onClick={() => moveLink(link.id, -1)}
                          >
                            <ChevronRight size={16} className="rot-up" />
                          </button>
                          <button
                            className="icon-btn"
                            aria-label="Move link down"
                            disabled={profile.links.indexOf(link) === profile.links.length - 1}
                            onClick={() => moveLink(link.id, 1)}
                          >
                            <ChevronRight size={16} className="rot-down" />
                          </button>
                          <button className="icon-btn" aria-label="Duplicate link" onClick={() => duplicateLink(link.id)}>
                            <Plus size={16} />
                          </button>
                          <label className="link-active">
                            <input
                              type="checkbox"
                              checked={link.active}
                              onChange={e => updateLink(link.id, 'active', e.target.checked)}
                            />
                            Visible
                          </label>
                          <button
                            className="icon-btn danger"
                            aria-label="Remove link"
                            onClick={() => update('links', profile.links.filter(item => item.id !== link.id))}
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    ))}
                    {profile.links.length === 0 && <p className="muted">No links yet. Select Add link to create your first button.</p>}
                  </div>
                  <div className="panel">
                    <div className="panel-head"><h3>Social media profiles</h3><span>QUICK ADD</span></div>
                    <p className="muted">Add Instagram, TikTok, Facebook, X, YouTube, LinkedIn and other social profiles as visible buttons.</p>
                    <label>Platform
                      <select value={socialPlatform} onChange={e => setSocialPlatform(e.target.value)}>
                        <option>Instagram</option><option>TikTok</option><option>Facebook</option><option>X / Twitter</option><option>YouTube</option><option>LinkedIn</option><option>Snapchat</option><option>Pinterest</option><option>Telegram</option><option>Other</option>
                      </select>
                    </label>
                    <label>Profile URL<input value={socialUrl} onChange={e => setSocialUrl(e.target.value)} placeholder="https://instagram.com/yourname" /></label>
                    <button className="btn btn-dark btn-small" onClick={addSocialLink}><Plus size={15}/> Add social media link</button>
                  </div>
                  <div className="panel">
                    <div className="panel-head">
                      <h3>Contact details</h3>
                      <span>02 / CONNECT</span>
                    </div>
                    <label>
                      WhatsApp number
                      <input
                        value={profile.whatsapp}
                        onChange={e => update('whatsapp', e.target.value)}
                        placeholder="2348012345678"
                      />
                    </label>
                    <label>
                      Business email
                      <input
                        value={profile.email}
                        onChange={e => update('email', e.target.value)}
                        placeholder="hello@yourbusiness.com"
                      />
                    </label>
                  </div>
                  <div className="panel">
                    <div className="panel-head"><h3>Brand logo</h3><span>UPLOAD</span></div>
                    <label>Upload logo or profile image<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e => e.target.files?.[0] && uploadLogo(e.target.files[0])} /></label>
                    {profile.avatar && <img src={profile.avatar} alt="Brand logo" style={{width:76,height:76,objectFit:'cover',borderRadius:18}} />}
                  </div>
                  <div className="panel">
                    <div className="panel-head"><h3>Background media</h3><span>IMAGE OR VIDEO</span></div>
                    <p className="muted">Upload a photo or looping background video (PNG, JPG, WEBP, MP4 or WEBM; maximum 15 MB).</p>
                    <label>Choose background<input type="file" accept="image/png,image/jpeg,image/webp,video/mp4,video/webm" disabled={backgroundBusy} onChange={e => e.target.files?.[0] && uploadBackground(e.target.files[0])} /></label>
                    {backgroundBusy && <p className="muted">Uploading…</p>}
                    {profile.backgroundUrl && <button className="btn btn-outline btn-small" onClick={() => { update('backgroundUrl' as keyof Profile, '' as any); update('backgroundPath' as keyof Profile, '' as any); update('backgroundType' as keyof Profile, undefined as any); }}>Remove background</button>}
                    <p className="muted">Current: {profile.backgroundType || 'Default theme'}</p>
                  </div>
                  <div className="panel">
                    <div className="panel-head">
                      <h3>Templates</h3>
                      <span>START HERE</span>
                    </div>
                    <p className="muted">
                      Pick a starting style. It sets your colours and theme, and fills empty fields with starter text and links. Anything you have already written is kept. Free accounts can use Studio and Consultant; subscribers get every template.
                    </p>
                    <div className="template-grid">
                      {TEMPLATE_PRESETS.map(t => {
                        const locked = !templateAllowed(t.id, profile);
                        return (
                          <button
                            key={t.id}
                            className={'template-card' + (locked ? ' locked' : '')}
                            onClick={() => applyTemplate(t)}
                            aria-disabled={locked}
                          >
                            <span className="template-swatch" style={{ background: t.accent }} />
                            <b>
                              {t.name} {locked && <em className="lock-badge">Subscribers</em>}
                            </b>
                            <small>{t.use}</small>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div className="panel">
                    <div className="panel-head">
                      <h3>Page appearance</h3>
                      <span>03 / STYLE</span>
                    </div>
                    <label>
                      Accent colour
                      <div className="color-row">
                        <input
                          type="color"
                          value={profile.accent}
                          onChange={e => update('accent', e.target.value)}
                        />
                        <span>{profile.accent}</span>
                      </div>
                    </label>
                    <label>
                      Theme
                      <select
                        value={profile.theme}
                        onChange={e => update('theme', e.target.value)}
                      >
                        <option value="dark">Midnight</option>
                        <option value="light">Clean light</option>
                        <option value="gradient">Aurora gradient</option>
                        <option value="minimal">Minimal studio</option>
                        <option value="bold">Bold editorial</option>
                      </select>
                    </label>
                  </div>
                  <div className="editor-actions">
                    <button
                      className="btn btn-dark"
                      onClick={save}
                      disabled={loading}
                    >
                      {loading ? 'Saving…' : 'Save changes'} <Check size={16} />
                    </button>
                    <button
                      className="btn btn-lime"
                      onClick={publish}
                      disabled={loading}
                    >
                      Publish page <Rocket size={16} />
                    </button>
                  </div>
                </div>
                {fullPreview && (
                  <div className="full-preview">
                    <PublicPage profile={profile} onBack={() => setFullPreview(false)} />
                  </div>
                )}
                <div className="preview-column">
                  <div className="preview-sticky">
                    <div className="preview-caption">
                      <span>LIVE PREVIEW</span>
                      <span>
                        <i /> PREVIEW
                      </span>
                      <button className="preview-full" onClick={() => setFullPreview(true)}>
                        Full screen <ArrowUpRight size={13} />
                      </button>
                    </div>
                    <div
                      className={
                        'preview-phone ' +
                        (profile.theme === 'light' ? 'light' : '')
                      }
                      style={{ '--accent': profile.accent } as any}
                    >
                      <div className="preview-avatar">
                        {profile.name.slice(0, 1).toUpperCase()}
                      </div>
                      <h3>{profile.name || 'Your business'}</h3>
                      <b>{profile.headline}</b>
                      <p>{profile.bio}</p>
                      {profile.links
                        .filter(l => l.active)
                        .map(l => (
                          <div className="preview-link" key={l.id}>
                            {l.title}
                            <ArrowUpRight size={14} />
                          </div>
                        ))}
                      {profile.services.map(s => (
                        <div className="preview-service" key={s.title}>
                          <b>{s.title}</b>
                          <span>{s.description}</span>
                          <small>{s.price}</small>
                        </div>
                      ))}
                      <small className="preview-brand">
                        Made with mavvlink.
                      </small>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {view === 'domains' && !canUseCustomDomain(profile) && (
              <div className="panel locked-panel">
                <div className="panel-head"><h3>Custom domain</h3><span className="lock-badge">Growth and above</span></div>
                <p className="muted">Connect your own domain, such as links.yourbusiness.com, with the Growth plan or above.</p>
                <button className="btn btn-lime" onClick={() => setView('pricing' as any)}>See plans <ArrowUpRight size={15} /></button>
              </div>
            )}
            {view === 'domains' && canUseCustomDomain(profile) && <div className="panel">
              <div className="panel-head"><h3>Connect your own domain</h3><span>DOMAIN REQUEST</span></div>
              <p className="muted">Request a domain such as links.yourbusiness.com. Requests are reviewed by the mavvlink owner. DNS verification and live custom-domain routing are not enabled yet.</p>
              <label>Domain name<input value={domain} onChange={e => setDomain(e.target.value)} placeholder="links.yourbusiness.com" /></label>
              <button className="btn btn-lime" onClick={requestDomain}>Submit domain request <ArrowUpRight size={15}/></button>
              <p className="muted">Current request: {profile.customDomain || 'None'} · Status: {profile.domainStatus || 'Not requested'}</p>
            </div>}
            {view === 'admin' && <div className="panel">
              <div className="panel-head"><h3>mavvlink owner console</h3><span>OWNER ONLY</span></div>
              {!adminData ? <p>Loading administration data…</p> : <>
                <div className="stats-grid">
                  <div className="stat-card"><span>BUSINESSES</span><b>{adminData.total}</b></div>
                  <div className="stat-card"><span>ACTIVE PLANS</span><b>{adminData.active}</b></div>
                  <div className="stat-card"><span>PAGE VIEWS</span><b>{adminData.views}</b></div>
                  <div className="stat-card"><span>LINK CLICKS</span><b>{adminData.clicks}</b></div>
                </div>
                <p className="muted">Indicative monthly plan value: ₦{Number(adminData.indicativeMonthlyPlanValue || 0).toLocaleString()}. This is selected-plan value, not collected revenue; payments are not connected.</p>
                <h3>Business subscriptions</h3>
                {adminData.businesses.map((b:any) => <div className="link-editor-row" key={b.id}>
                  <div><b>{b.name}</b><p className="muted">/{b.slug} · {b.plan} · {b.subscriptionStatus} · Expires {b.expiresAt || 'not set'}</p></div>
                  <button className="btn btn-outline btn-small" onClick={async () => { const date = window.prompt('Set expiry date (YYYY-MM-DD), leave blank to clear:', b.expiresAt?.slice(0,10) || ''); if (date === null) return; await api.put('/api/admin/subscription/' + b.id, {plan:b.plan || 'Free',status:'active',expiresAt:date ? new Date(date).toISOString() : ''}); const fresh=await api.get('/api/admin'); setAdminData(fresh.data); }}>Set expiry</button>
                  <button className="btn btn-outline btn-small" onClick={async () => { await api.put('/api/admin/subscription/' + b.id, {plan:b.plan || 'Free',status:'cancelled',expiresAt:b.expiresAt || ''}); const fresh=await api.get('/api/admin'); setAdminData(fresh.data); }}>Cancel</button>
                </div>)}
                <h3>Custom domain requests</h3>
                {adminData.domains.map((d:any) => <div className="link-editor-row" key={d.id}><div><b>{d.domain}</b><p className="muted">{d.status}</p></div><button className="btn btn-outline btn-small" onClick={async () => { await api.put('/api/admin/domain/' + d.userId, {status:'approved'}); const fresh=await api.get('/api/admin'); setAdminData(fresh.data); }}>Approve request</button></div>)}
              </>}
            </div>}
            {view === 'services' && (
              <>
              <div className="panel">
                <div className="panel-head">
                  <div>
                    <h3>Products</h3>
                    <p className="muted">
                      Show what you sell: a photo, a name and the link where customers buy.
                      {isSubscriber(profile)
                        ? ' Subscribers can add up to 12 products.'
                        : ' Free accounts can add 2 products.'}
                    </p>
                    {!isSubscriber(profile) && (
                      <button className="btn btn-lime btn-small" onClick={() => setView('pricing')}>
                        Subscribe for up to 12 products <ArrowUpRight size={14} />
                      </button>
                    )}
                  </div>
                  <button
                    className="btn btn-dark btn-small"
                    onClick={addProduct}
                    disabled={(profile.products ?? []).length >= productLimit(profile)}
                  >
                    <Plus size={15} /> Add product
                  </button>
                </div>
                {(profile.products ?? []).map((p, i, all) => (
                  <div className="service-edit" key={p.id}>
                    <div className="service-number">0{i + 1}</div>
                    <div className="service-fields">
                      <label>
                        Product photo
                        <div className="product-upload">
                          {p.image ? <img src={p.image} alt="" /> : <span>No photo yet</span>}
                          <input
                            type="file"
                            accept="image/png,image/jpeg,image/webp"
                            onChange={e => {
                              const f = e.target.files?.[0];
                              if (f) uploadProductImage(p.id, f);
                              e.target.value = '';
                            }}
                          />
                        </div>
                      </label>
                      <label>
                        Product name
                        <input value={p.title} onChange={e => patchProduct(p.id, { title: e.target.value })} />
                      </label>
                      <label>
                        Link where customers buy
                        <input value={p.url} placeholder="https://" onChange={e => patchProduct(p.id, { url: e.target.value })} />
                      </label>
                      <label>
                        Price (optional)
                        <input value={p.price} onChange={e => patchProduct(p.id, { price: e.target.value })} />
                      </label>
                    </div>
                    <div className="product-actions">
                      <button className="icon-btn" aria-label="Move product up" disabled={i === 0} onClick={() => moveProduct(i, -1)}>
                        <ChevronRight size={16} className="rot-up" />
                      </button>
                      <button className="icon-btn" aria-label="Move product down" disabled={i === all.length - 1} onClick={() => moveProduct(i, 1)}>
                        <ChevronRight size={16} className="rot-down" />
                      </button>
                      <button className="icon-btn danger" aria-label="Remove product" onClick={() => removeProduct(p.id)}>
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="panel">
                <div className="panel-head">
                  <div>
                    <h3>Social profiles</h3>
                    <p className="muted">Add the links you use. Icons appear on your page when the template shows them.</p>
                  </div>
                  <label className="xp-check">
                    <input type="checkbox" checked={!!profile.showSocials} onChange={e => update('showSocials', e.target.checked)} />
                    Show icons
                  </label>
                </div>
                {SOCIALS.map(s => (
                  <label key={s.key} className="social-field">
                    <span className="social-chip"><SocialIcon k={s.key} /></span>
                    <span className="social-name">{s.label}</span>
                    <input
                      value={profile.socials?.[s.key] ?? ''}
                      placeholder={s.placeholder}
                      onChange={e => update('socials', { ...(profile.socials ?? {}), [s.key]: e.target.value })}
                    />
                  </label>
                ))}
              </div>
              <div className="panel">
                <div className="panel-head">
                  <div>
                    <h3>Services and offers</h3>
                    <p className="muted">
                      Give visitors a clear reason to contact or buy from you.
                    </p>
                  </div>
                  <button
                    className="btn btn-dark btn-small"
                    onClick={addService}
                  >
                    <Plus size={15} /> Add service
                  </button>
                </div>
                {profile.services.map((s, i) => (
                  <div className="service-edit" key={i}>
                    <div className="service-number">0{i + 1}</div>
                    <div className="service-fields">
                      <label>
                        Service name
                        <input
                          value={s.title}
                          onChange={e =>
                            update(
                              'services',
                              profile.services.map((x, j) =>
                                j === i ? { ...x, title: e.target.value } : x
                              )
                            )
                          }
                        />
                      </label>
                      <label>
                        Description
                        <input
                          value={s.description}
                          onChange={e =>
                            update(
                              'services',
                              profile.services.map((x, j) =>
                                j === i
                                  ? { ...x, description: e.target.value }
                                  : x
                              )
                            )
                          }
                        />
                      </label>
                      <label>
                        Price or call to action
                        <input
                          value={s.price}
                          onChange={e =>
                            update(
                              'services',
                              profile.services.map((x, j) =>
                                j === i ? { ...x, price: e.target.value } : x
                              )
                            )
                          }
                        />
                      </label>
                    </div>
                    <button
                      className="icon-btn danger"
                      onClick={() =>
                        update(
                          'services',
                          profile.services.filter((_, j) => j !== i)
                        )
                      }
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
                <button
                  className="btn btn-lime"
                  onClick={save}
                  disabled={loading}
                >
                  Save services <Check size={16} />
                </button>
              </div>
              </>
            )}
            {view === 'plans' && (
              <>
                <div className="billing-banner">
                  <ShieldCheck size={24} />
                  <div>
                    <b>Choose the tools that fit your next stage.</b>
                    <p>
                      Plan selection is saved to your workspace. Online
                      recurring payments can be connected when your payment
                      provider is configured.
                    </p>
                  </div>
                </div>
                <CurrencyPicker value={currency} onChange={setCurrency} />
                <div className="pricing-grid dashboard-pricing">
                  {plans.map((p, i) => (
                    <div
                      className={
                        'price-card ' +
                        (profile.plan === p.name ? 'selected-plan' : '')
                      }
                      key={p.name}
                    >
                      <h3>
                        {p.name}{' '}
                        {profile.plan === p.name && (
                          <span className="current-label">CURRENT</span>
                        )}
                      </h3>
                      <p>{p.note}</p>
                      <div className="price">
                        {formatPrice(p.ngn, currency)}
                        <small>{i === 0 ? '' : ' / month'}</small>
                      </div>
                      <ul>
                        {p.features.map(f => (
                          <li key={f}>
                            <Check size={15} />
                            {f}
                          </li>
                        ))}
                      </ul>
                      <button
                        className={
                          profile.plan === p.name
                            ? 'btn btn-outline'
                            : 'btn btn-dark'
                        }
                        onClick={() => {
                          update('plan', p.name);
                          setNotice(
                            p.name +
                              ' selected. Save to confirm your plan preference.'
                          );
                        }}
                      >
                        Select {p.name}
                      </button>
                    </div>
                  ))}
                </div>
                <button className="btn btn-lime" onClick={save}>
                  Save plan selection <Check size={16} />
                </button>
              </>
            )}
          </div>
        </div>
      )}
      {view !== 'about' && (
        <SiteFooter go={goView} onStart={goSignup} onLogin={signIn} signedIn={!!user} onSignOut={handleSignOut} onSubscribe={subscribeNewsletter} />
      )}
    </div>
  );
}



function ServicesPage({ onGetStarted }: { onGetStarted: () => void }) {
  const offerings = [
    { icon: <LayoutDashboard />, tag: '01 / BUILD', title: 'A page that represents your brand', copy: 'Create a polished, mobile-friendly business page with your story, identity and the essentials visitors need.', points: ['Custom profile and page styling', 'Image and video backgrounds', 'Ready-to-share public page'] },
    { icon: <Link2 />, tag: '02 / CONNECT', title: 'All your important links, together', copy: 'Bring your website, social profiles, booking links and contact channels into one easy destination.', points: ['Social profile buttons', 'Flexible link management', 'Direct WhatsApp and email contact'] },
    { icon: <Store />, tag: '03 / SHOWCASE', title: 'Turn services into clear next steps', copy: 'Present what you offer, explain the value and make it simple for customers to enquire.', points: ['Service descriptions and pricing', 'Clear enquiry calls to action', 'Easy updates from your dashboard'] },
    { icon: <BarChart3 />, tag: '04 / UNDERSTAND', title: 'Learn what gets attention', copy: 'Use page and link activity insights to understand how visitors interact with your public page.', points: ['Page visit totals', 'Tracked link clicks', 'A simple business overview'] },
    { icon: <Globe2 />, tag: '05 / GROW', title: 'Make your page your own', copy: 'Build a more recognisable presence as your business grows, with customisation options and domain requests.', points: ['Theme and accent controls', 'Custom domain requests', 'Plan options for growing teams'] },
    { icon: <ShieldCheck />, tag: '06 / MANAGE', title: 'A simple workspace to manage it all', copy: 'Keep your page content and business details organised in one place without needing to write code.', points: ['Straightforward page editor', 'Service and link management', 'Publish updates when ready'] },
  ];
  return (
    <main className="services-page">
      <section className="services-hero">
        <div className="wrap services-hero-grid">
          <div>
            <div className="eyebrow"><Sparkles size={14}/> THE MAVVLINK PLATFORM</div>
            <h1>Everything your<br/><span>business page needs.</span></h1>
            <p>From your first shareable link to a polished digital front door, mavvlink brings the tools to present your business and help people take action.</p>
            <button className="btn btn-lime" onClick={onGetStarted}>Build your mavvlink page <ArrowUpRight size={16}/></button>
          </div>
          <div className="services-hero-art" aria-hidden="true">
            <div className="services-art-orbit orbit-a"/><div className="services-art-orbit orbit-b"/>
            <div className="services-art-core"><BrandMark /></div>
            <div className="services-art-node service-node-a"><Link2/></div><div className="services-art-node service-node-b"><Store/></div><div className="services-art-node service-node-c"><BarChart3/></div>
          </div>
        </div>
      </section>
      <section className="wrap services-intro">
        <div className="eyebrow">ONE PLATFORM. MORE POSSIBILITIES.</div>
        <h2>Tools that make your<br/><span>next step feel simple.</span></h2>
        <p>Choose what your business needs today. Your page can grow as your ideas, audience and services grow.</p>
      </section>
      <section className="wrap services-grid">
        {offerings.map((item, index) => <article className="service-feature-card" key={item.tag} style={{animationDelay:(index*.08)+'s'}}>
          <div className="service-feature-top"><span>{item.tag}</span><div>{item.icon}</div></div>
          <h3>{item.title}</h3><p>{item.copy}</p>
          <ul>{item.points.map(point => <li key={point}><Check size={15}/>{point}</li>)}</ul>
          <span className="service-feature-number">0{index+1}</span>
        </article>)}
      </section>
      <section className="services-bottom-cta"><div className="wrap"><div className="eyebrow">READY TO BRING IT TOGETHER?</div><h2>Your business deserves<br/><span>one beautiful destination.</span></h2><button className="btn btn-lime" onClick={onGetStarted}>Get started with mavvlink <ArrowUpRight size={16}/></button></div></section>
    </main>
  );
}

function AboutPage({ onGetStarted, go, onLogin, signedIn, onSignOut, onSubscribe }: { onGetStarted: () => void; go: (v: string) => void; onLogin: () => void; signedIn: boolean; onSignOut: () => void; onSubscribe: (email: string) => Promise<string | null> }) {
  const values = [
    {
      number: '01',
      title: 'Clarity over clutter',
      copy: 'Give every important destination a clear place. Your audience should know where to go and what to do next.',
    },
    {
      number: '02',
      title: 'Built for real businesses',
      copy: 'A polished home for services, social channels, enquiries and the details that help customers trust your brand.',
    },
    {
      number: '03',
      title: 'Simple, with room to grow',
      copy: 'Start with one page and a few links. Add richer content, custom styling and insights as your business evolves.',
    },
  ];

  return (
    <main className="about-page">
      <section className="about-hero">
        <div className="about-hero-glow" />
        <div className="wrap about-hero-inner">
          <div className="about-hero-copy">
            <div className="eyebrow"><Sparkles size={14} /> A LITTLE ABOUT MAVVLINK</div>
            <h1>We connect the dots<br /><span>between you and your audience.</span></h1>
            <p>
              Your business lives across websites, social channels, services and conversations.
              mavvlink brings the important pieces together in one thoughtful, beautiful place.
            </p>
            <div className="about-hero-actions">
              <button className="btn btn-lime" onClick={onGetStarted}>Create your page <ArrowUpRight size={16} /></button>
              <a className="about-scroll-link" href="#our-purpose">Discover our purpose <ChevronRight size={16} /></a>
            </div>
          </div>
          <div className="about-orbit-art" aria-hidden="true">
            <div className="about-orbit-ring ring-a" />
            <div className="about-orbit-ring ring-b" />
            <div className="about-orbit-core"><BrandMark /></div>
            <div className="about-orbit-node node-one"><Link2 size={18} /></div>
            <div className="about-orbit-node node-two"><Store size={18} /></div>
            <div className="about-orbit-node node-three"><BarChart3 size={18} /></div>
            <div className="about-orbit-node node-four"><MessageCircle size={18} /></div>
          </div>
          <div className="about-scroll-cue">SCROLL TO EXPLORE <span /></div>
        </div>
      </section>

      <div className="wrap social-band-wrap">
        <SocialMarquee />
      </div>
      <section className="about-purpose wrap" id="our-purpose">
        <div className="about-purpose-label">
          <div className="eyebrow">WHY WE EXIST</div>
          <span className="about-index">01 / OUR PURPOSE</span>
        </div>
        <div className="about-purpose-copy">
          <h2>Less searching.<br /><span>More meaningful connections.</span></h2>
          <p>
            We believe a simple link can open the door to something much bigger.
            mavvlink is designed to make it easier for people to discover what you do,
            explore what you offer and reach you without getting lost along the way.
          </p>
        </div>
      </section>

      <section className="about-values">
        <div className="wrap">
          <div className="about-section-head">
            <div><div className="eyebrow">THE THINKING BEHIND THE PLATFORM</div><h2>Small details.<br /><span>Big difference.</span></h2></div>
            <p>We keep the experience focused on what matters: your identity, your work and the next step your visitors can take.</p>
          </div>
          <div className="about-value-grid">
            {values.map(value => (
              <article className="about-value-card" key={value.number}>
                <span className="about-value-number">{value.number}</span>
                <div className="about-value-icon">{value.number === '01' ? <Sparkles /> : value.number === '02' ? <Store /> : <Rocket />}</div>
                <h3>{value.title}</h3>
                <p>{value.copy}</p>
                <span className="about-value-line" />
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="about-how wrap">
        <div className="about-how-visual">
          <div className="about-mini-window">
            <div className="about-mini-top"><i /><i /><i /><span>YOUR MAVVLINK PAGE</span></div>
            <div className="about-mini-profile"><div className="about-mini-avatar"><img src={eyeImage} alt="" /></div><b>Your business, beautifully presented.</b><small>Links · Services · Contact</small></div>
            <div className="about-mini-link"><Globe2 size={16} /> Your website <ArrowUpRight size={14} /></div>
            <div className="about-mini-link"><Store size={16} /> Explore our services <ArrowUpRight size={14} /></div>
            <div className="about-mini-link"><MessageCircle size={16} /> Start a conversation <ArrowUpRight size={14} /></div>
            <div className="about-mini-footer">ONE LINK. MORE POSSIBILITIES.</div>
          </div>
          <div className="about-floating-note"><span className="live-dot" /> Your digital front door</div>
        </div>
        <div className="about-how-copy">
          <div className="eyebrow">HOW MAVVLINK HELPS</div>
          <h2>Everything in its place.<br /><span>Ready to be shared.</span></h2>
          <p>Build a page that introduces your business, brings your social profiles together, highlights your services and gives visitors a direct way to contact you.</p>
          <ul>
            <li><Check size={17} /> One shareable business page</li>
            <li><Check size={17} /> Links, social profiles and services</li>
            <li><Check size={17} /> Brand styling and media backgrounds</li>
            <li><Check size={17} /> Page insights as your audience grows</li>
          </ul>
          <button className="btn btn-lime" onClick={onGetStarted}>Make your mavvlink page <ArrowUpRight size={16} /></button>
        </div>
      </section>

      <section className="about-cta">
        <div className="wrap about-cta-inner">
          <div className="eyebrow">YOUR NEXT CHAPTER STARTS HERE</div>
          <h2>Bring your business<br /><span>together in one link.</span></h2>
          <p>Make it easier for people to find you, understand you and connect with you.</p>
          <button className="btn btn-lime" onClick={onGetStarted}>Get started with mavvlink <ArrowUpRight size={16} /></button>
        </div>
      </section>
      <SiteFooter go={go} onStart={onGetStarted} onLogin={onLogin} signedIn={signedIn} onSignOut={onSignOut} onSubscribe={onSubscribe} />
    </main>
  );
}

function PublicPage({ profile, onBack }: { profile: Profile | null; onBack?: () => void }) {

  if (!profile)
    return (
      <div className="public-not-found">
        <BrandMark />
        <h2>Page not found</h2>
        <p>This page may have moved or is not published yet.</p>
        <a href="#">
          Create your own page <ArrowUpRight size={15} />
        </a>
      </div>
    );
  // The page follows the chosen theme; there is no visitor light/dark switch.
  const light = profile?.theme === 'light';
  return (
    <div
      className={'public-page theme-' + profile.theme + (light ? ' public-light' : '')}
      style={{ '--accent': profile.accent, backgroundImage: profile.backgroundUrl && profile.backgroundType === 'image' ? 'linear-gradient(#0008,#0009), url(' + profile.backgroundUrl + ')' : undefined, backgroundSize:'cover', backgroundPosition:'center' } as any}
    >
      {profile.backgroundUrl && profile.backgroundType === 'video' && <video className="public-background-video" style={{position:"fixed",inset:0,width:"100%",height:"100%",objectFit:"cover",zIndex:0,pointerEvents:"none"}} src={profile.backgroundUrl} autoPlay muted loop playsInline />}
      {onBack && <button style={{position:"fixed",top:18,left:18,zIndex:5,padding:"11px 16px",borderRadius:999,border:"1px solid #ffffff40",color:"#fff",background:"#111c",fontWeight:700}} onClick={onBack}>← Back to editor</button>}
      <div className="public-card" style={{position:"relative",zIndex:1}}>
        <div className="public-avatar">
          {profile.avatar ? <img src={profile.avatar} alt={profile.name + ' logo'} style={{width:'100%',height:'100%',objectFit:'cover',borderRadius:'inherit'}} /> : profile.name.slice(0, 1).toUpperCase()}
        </div>
        <h1>{profile.name}</h1>
        <h2>{profile.headline}</h2>
        <p>{profile.bio}</p>
        <div className="public-links">
          {profile.links
            .filter(l => l.active)
            .map(l => (
              <a
                href={safeUrl(l.url)}
                target="_blank"
                rel="noreferrer"
                key={l.id}
                onClick={() => api.post('/api/event', { slug: profile.slug, type: 'click', linkTitle: l.title }).catch(() => {})}
              >
                {l.title}
                <ArrowUpRight size={16} />
              </a>
            ))}
        </div>
        {profile.showSocials && SOCIALS.some(s => profile.socials?.[s.key]) && (
          <div className="public-socials">
            {SOCIALS.filter(s => profile.socials?.[s.key]).map((s, i) => (
              <a
                key={s.key}
                href={safeUrl(profile.socials![s.key]!)}
                target="_blank"
                rel="noreferrer"
                aria-label={s.label}
                style={{ animationDelay: `${i * 0.06}s` }}
              >
                <SocialIcon k={s.key} size={18} />
              </a>
            ))}
          </div>
        )}
        {(profile.products ?? []).some(p => p.title || p.image) && (
          <div className="public-products">
            <span className="public-label">PRODUCTS</span>
            <div className="public-product-grid">
              {(profile.products ?? []).filter(p => p.title || p.image).slice(0, productLimit(profile)).map(p => (
                <a
                  key={p.id}
                  className="public-product"
                  href={p.url ? safeUrl(p.url) : undefined}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => api.post('/api/event', { slug: profile.slug, type: 'click', linkTitle: 'Product: ' + p.title }).catch(() => {})}
                >
                  <div className="public-product-img">{p.image ? <img src={p.image} alt={p.title} /> : <span />}</div>
                  <b>{p.title}</b>
                  {p.price && <small>{p.price}</small>}
                </a>
              ))}
            </div>
          </div>
        )}
        {profile.services.length > 0 && (
          <div className="public-services">
            <span className="public-label">WHAT WE OFFER</span>
            {profile.services.map((s, i) => (
              <article key={i}>
                <b>{s.title}</b>
                <p>{s.description}</p>
                <small>{s.price}</small>
              </article>
            ))}
          </div>
        )}
        {(profile.whatsapp || profile.email) && (
          <div className="public-contact">
            <span className="public-label">LET'S CONNECT</span>
            {profile.whatsapp && (
              <a href={'https://wa.me/' + profile.whatsapp.replace(/\D/g, '')}>
                <MessageCircle size={16} /> Chat on WhatsApp
              </a>
            )}
            {profile.email && (
              <a href={'mailto:' + profile.email}>
                <ExternalLink size={16} /> Send an email
              </a>
            )}
          </div>
        )}
        <div className="public-footer">
          Made with <b>mavvlink.</b>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <>
      <AppInner />
      <Agent />
    </>
  );
}
