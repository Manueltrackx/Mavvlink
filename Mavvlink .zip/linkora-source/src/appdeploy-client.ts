// @ts-nocheck
// Demo stand-in for the platform SDK (@appdeploy/client). It is not published to npm, so the
// deployed site uses this instead: sign-in, saving and uploads are simulated in the browser,
// and nothing is stored on a server. Replace it with a real auth and backend client to go live.
// Offline preview stub for @appdeploy/client. Signed-in state lives in the URL hash (#demo),
// so no storage APIs are used.
const DEMO_PROFILE = {
  name: 'Mavvlink', slug: 'mavvlink',
  headline: 'Brand strategy for ambitious teams.',
  bio: 'We help businesses look and sound like who they really are.',
  avatar: '', accent: '#9bf36b', theme: 'dark',
  links: [
    { id: '1', title: 'Book a call', url: 'https://example.com/call', kind: 'Website', active: true },
    { id: '2', title: 'Chat on WhatsApp', url: 'https://wa.me/2348000000000', kind: 'WhatsApp', active: true },
  ],
  services: [
    { title: 'Brand strategy', description: 'Positioning, naming and messaging.', price: 'From ₦250,000' },
    { title: 'Website design', description: 'Fast, mobile-first sites.', price: 'Get a quote' },
  ],
  whatsapp: '', email: 'hello@mavvlink.example', plan: 'Pro', views: 128,
  subscriptionStatus: 'active', expiresAt: '2027-12-01T00:00:00.000Z', customDomain: '', domainStatus: '',
};
const BLANK_PROFILE = {
  name: 'Your Business', slug: 'your-business', headline: 'Everything you do, in one link.',
  bio: 'Tell people what you do and make it easy for them to take the next step.', avatar: '',
  accent: '#9bf36b', theme: 'dark', links: [], services: [], whatsapp: '', email: '', plan: 'Free',
  views: 0, subscriptionStatus: 'active',
};
const isSignedIn = () => (typeof location !== 'undefined' && location.hash.includes('demo'));
export const auth = {
  getUser: async () => (isSignedIn() ? { userId: 'demo', email: 'owner@mavvlink.example', name: 'Mavvlink Owner' } : null),
  // Keep any sign-up details across the reload. A new account is marked "fresh".
  signInWithRedirect: async () => {
    const draft = localStorage.getItem('linkora-signup-draft');
    location.hash = 'demo' + (draft ? '&fresh&draft=' + encodeURIComponent(draft) : '');
    location.reload();
  },
  signOut: async () => { location.hash = ''; location.reload(); },
};
const ok = (data) => Promise.resolve({ data });
export const api = {
  get: (path) => {
    if (path === '/api/site') {
      const fresh = location.hash.includes('fresh');
      return ok({ profile: fresh ? BLANK_PROFILE : DEMO_PROFILE });
    }
    if (path === '/api/analytics') return ok({ views: 128, clicks: 41, recent: [] });
    if (path === '/api/admin') return ok({
      businesses: [{ ...DEMO_PROFILE, id: 'demo', subscriptionStatus: 'active' }], domains: [],
      total: 1, active: 1, views: 128, clicks: 41, indicativeMonthlyPlanValue: 12000,
    });
    if (path.startsWith('/api/public/')) return ok({ profile: DEMO_PROFILE });
    return ok({});
  },
  post: (path, body) => {
    // Mirror the real backend: return the stored file's path and a URL the page can display.
    if (path === '/api/upload') {
      return ok({ path: 'preview/logo', url: `data:${body.contentType};base64,${body.data}` });
    }
    if (path === '/api/background-upload') {
      return ok({
        path: 'preview/background',
        url: `data:${body.contentType};base64,${body.data}`,
        type: String(body.contentType).startsWith('video/') ? 'video' : 'image',
      });
    }
    return ok({ ok: true, ...(body || {}) });
  },
  put: (_p, body) => {
    // Setup is done: drop the "fresh" marker so a reload shows the normal demo account.
    if (typeof history !== 'undefined') history.replaceState(null, '', '#demo');
    return ok({ updated: true, profile: body?.profile });
  },
  delete: () => ok({ ok: true }),
};
