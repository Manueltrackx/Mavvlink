export type Plan = { name: string; price: string; ngn: number; note: string; features: string[] };

export const plans: Plan[] = [
  {
    name: 'Free',
    price: '₦0',
    ngn: 0,
    note: 'Try your business page',
    features: ['One published page', 'Up to 5 links', 'Basic themes'],
  },
  {
    name: 'Growth',
    price: '₦5,000',
    ngn: 5000,
    note: 'For growing businesses',
    features: [
      'Everything in Free',
      'Unlimited links and services',
      'Visitor insights',
      'Custom themes',
      'Custom domain connection',
    ],
  },
  {
    name: 'Pro',
    price: '₦12,000',
    ngn: 12000,
    note: 'For brands that mean business',
    features: [
      'Everything in Growth',
      'Lead capture',
      'Priority support',
    ],
  },
];
