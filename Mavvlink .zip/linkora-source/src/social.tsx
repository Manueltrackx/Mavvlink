// Social profile keys, labels and clean monochrome icons (drawn in SVG, currentColor).
export type SocialKey = 'instagram' | 'tiktok' | 'x' | 'youtube' | 'facebook' | 'linkedin' | 'whatsapp' | 'telegram';

export const SOCIALS: { key: SocialKey; label: string; placeholder: string }[] = [
  { key: 'instagram', label: 'Instagram', placeholder: 'https://instagram.com/yourname' },
  { key: 'tiktok', label: 'TikTok', placeholder: 'https://tiktok.com/@yourname' },
  { key: 'x', label: 'X (Twitter)', placeholder: 'https://x.com/yourname' },
  { key: 'youtube', label: 'YouTube', placeholder: 'https://youtube.com/@yourname' },
  { key: 'facebook', label: 'Facebook', placeholder: 'https://facebook.com/yourpage' },
  { key: 'linkedin', label: 'LinkedIn', placeholder: 'https://linkedin.com/in/yourname' },
  { key: 'whatsapp', label: 'WhatsApp', placeholder: 'https://wa.me/2348000000000' },
  { key: 'telegram', label: 'Telegram', placeholder: 'https://t.me/yourname' },
];

export function SocialIcon({ k, size = 18 }: { k: SocialKey; size?: number }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true };
  switch (k) {
    case 'instagram':
      return (
        <svg {...common}>
          <rect x="3" y="3" width="18" height="18" rx="5" />
          <circle cx="12" cy="12" r="4.2" />
          <circle cx="17.2" cy="6.8" r="0.9" fill="currentColor" stroke="none" />
        </svg>
      );
    case 'tiktok':
      return (
        <svg {...common}>
          <path d="M14 3v11.2a3.3 3.3 0 1 1-3.3-3.3" />
          <path d="M14 3c.4 2.6 2.2 4.4 5 4.6" />
        </svg>
      );
    case 'x':
      return (
        <svg {...common}>
          <path d="M4 4l16 16M20 4L4 20" />
        </svg>
      );
    case 'youtube':
      return (
        <svg {...common}>
          <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
          <path d="M10.2 9.2v5.6l4.8-2.8z" fill="currentColor" stroke="none" />
        </svg>
      );
    case 'facebook':
      return (
        <svg {...common}>
          <path d="M14 8.2h2.6V4.6H14c-2.5 0-4.1 1.7-4.1 4.2v2.2H7.4v3.6h2.5V21h3.6v-6.4h2.6l.5-3.6h-3.1v-2.2c0-.6.3-1 1-1z" />
        </svg>
      );
    case 'linkedin':
      return (
        <svg {...common}>
          <rect x="3" y="3" width="18" height="18" rx="3" />
          <path d="M8 10.2V16M8 7.6v.1M11.6 16v-5.8M11.6 12.2c0-1.5 1-2.3 2.2-2.3 1.3 0 2.2.8 2.2 2.4V16" />
        </svg>
      );
    case 'telegram':
      return (
        <svg {...common}>
          <path d="M21.5 3.5L2.8 10.7c-.7.3-.7 1 0 1.2l4.6 1.5 1.8 5.6c.2.6.9.8 1.4.4l2.5-2.1 4.8 3.5c.5.4 1.2.1 1.4-.5l3.2-15.5c.2-.8-.5-1.4-1-1.3z" />
          <path d="M7.4 12.4l8.9-5.4" />
        </svg>
      );
    case 'whatsapp':
      return (
        <svg {...common}>
          <path d="M4.5 19.5l1.1-3.6A8 8 0 1 1 8.6 18.9z" />
          <path d="M9.2 9.6c.2 2 2.2 4.6 5.1 5.2l1.2-1.2" />
        </svg>
      );
  }
}

// Sliding band of social logos. The list is repeated so the loop joins up seamlessly.
export function SocialMarquee() {
  const items = [...SOCIALS, ...SOCIALS];
  return (
    <div className="social-marquee" aria-label="Social platforms supported">
      <div className="social-track">
        {items.map((s, i) => (
          <span key={s.key + i} className="social-logo" aria-hidden={i >= SOCIALS.length} style={{ animationDelay: `${(i % SOCIALS.length) * 0.3}s` }}>
            <SocialIcon k={s.key} size={20} />
            <em>{s.label}</em>
          </span>
        ))}
      </div>
    </div>
  );
}
