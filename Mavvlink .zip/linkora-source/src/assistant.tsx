import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, ChevronRight, Sparkles, X } from 'lucide-react';

type Link = { label: string; view: string };
type Entry = { keys: string[]; answer: string; link?: Link };
type Msg = { from: 'bot' | 'user'; text: string; link?: Link };

// What the assistant knows. Keep these answers in line with the site's pages.
const KNOWLEDGE: Entry[] = [
  { keys: ['what is', 'mavvlink', 'about', 'explain', 'platform'],
    answer: 'mavvlink is a business link page. You build one page with your name, links, services and contact details, then share one link everywhere you show up online.',
    link: { label: 'See templates', view: 'templates' } },
  { keys: ['price', 'pricing', 'cost', 'plan', 'plans', 'how much', 'subscription'],
    answer: 'There are three plans: Free (₦0), Growth (₦5,000) and Pro (₦12,000). Custom domains are on the Growth plan and above. Checkout is not connected yet.',
    link: { label: 'View pricing', view: 'pricing' } },
  { keys: ['currency', 'dollar', 'usd', 'pound', 'gbp', 'euro', 'naira', 'ngn', 'convert'],
    answer: 'Plan prices can be shown in naira, US dollars, British pounds or euros. Non-naira prices are indicative; the checkout currency is naira.',
    link: { label: 'View pricing', view: 'pricing' } },
  { keys: ['sign up', 'signup', 'create', 'register', 'account', 'get started', 'start'],
    answer: 'Click Create your free page. Enter your name, business name, email and page link, accept the terms, and sign in. Your page is set up with those details.',
    link: { label: 'Sign up', view: 'signup' } },
  { keys: ['log in', 'login', 'sign in', 'signin', 'password'],
    answer: 'Use Log in at the top of any page. Sign-in is not fully connected yet in this preview.',
    link: { label: 'Log in page', view: 'login' } },
  { keys: ['template', 'templates', 'design', 'theme', 'look', 'style'],
    answer: 'Templates give your page a starting look: Studio, Kitchen, Consultant, Shop, Creator and Clinic. Applying one sets the colour and theme and fills empty fields. Your own text and links are kept.',
    link: { label: 'Browse templates', view: 'templates' } },
  { keys: ['link', 'links', 'edit', 'reorder', 'move', 'duplicate', 'builder', 'add link'],
    answer: 'In the page builder you add, edit, reorder, duplicate or hide links. Use the arrows to move a link and the plus icon to duplicate it. Save to keep your changes.' },
  { keys: ['service', 'services', 'offer'],
    answer: 'Add services with a title, description and price in the services editor. Visitors see them on your page.' },
  { keys: ['share', 'public', 'whatsapp', 'copy', 'send', 'backup', 'download'],
    answer: 'The share kit on the dashboard has Share on WhatsApp, Copy page link and Download backup (your page as a file). Your public link is /p/ followed by your page link.' },
  { keys: ['domain', 'custom domain', 'own domain'],
    answer: 'Custom domains are on the Growth plan and above. Request one from the Custom domain page. It is reviewed before it goes live.' },
  { keys: ['analytics', 'stats', 'views', 'clicks', 'visitors', 'numbers'],
    answer: 'The analytics page shows page views, link clicks and where visitors come from. The numbers on the site are sample data; real figures appear once your page has visitors.',
    link: { label: 'Open analytics', view: 'analytics' } },
  { keys: ['affiliate', 'refer', 'referral', 'commission', 'earn'],
    answer: 'The affiliate programme lets you earn by referring businesses. Signed-in users get a referral link with copy and WhatsApp share. The commission rate and payout terms are still being confirmed.',
    link: { label: 'Affiliate page', view: 'affiliate' } },
  { keys: ['newsletter', 'subscribe', 'email updates', 'updates', 'tips'],
    answer: 'Use the email box in the footer to subscribe to updates and tips. Sending emails and unsubscribe links need a mail service that is not connected yet.' },
  { keys: ['lead', 'leads', 'enquiry', 'enquiries', 'inquiries', 'contact form'],
    answer: 'Lead capture is not built yet. Visitors can reach you through your links, WhatsApp and email. The contact form on this site does not send messages in this preview.',
    link: { label: 'Contact page', view: 'contact' } },
  { keys: ['payment', 'pay', 'checkout', 'card', 'bank'],
    answer: 'Checkout is not connected yet. When a payment provider is added, plans will be paid in naira.' },
  { keys: ['privacy', 'personal data', 'data', 'gdpr'],
    answer: 'The privacy policy is a draft and must be reviewed before launch. It explains what information is collected and how it is used.',
    link: { label: 'Privacy policy', view: 'privacy' } },
  { keys: ['terms', 'legal', 'conditions'],
    answer: 'The terms of service are a draft and need reviewed legal text before launch.',
    link: { label: 'Terms', view: 'terms' } },
  { keys: ['contact', 'support', 'help', 'human', 'team', 'talk'],
    answer: 'Use the Contact page to send a message, or the Help center for common questions.',
    link: { label: 'Help center', view: 'help' } },
  { keys: ['delete', 'remove account', 'close account', 'cancel'],
    answer: 'Cancellation terms are not written yet, so please contact the team about a specific case. Account deletion is not available in this preview.' },
  { keys: ['logo', 'brand', 'star'],
    answer: 'The mavvlink logo is the star mark, with the name in the header and footer.' },
  { keys: ['changelog', 'release', 'what changed', 'new'],
    answer: 'The changelog lists what has changed in this build.',
    link: { label: 'Changelog', view: 'changelog' } },
  { keys: ['dashboard', 'manage', 'my page'],
    answer: 'The dashboard is where you manage your page: links, services, appearance and the share kit. Sign in to open it.' },
  { keys: ['mobile', 'phone', 'app', 'ios', 'android'],
    answer: 'mavvlink works in any mobile browser. There is no separate app yet.' },
  { keys: ['hello', 'hi', 'hey'],
    answer: 'Hi! Ask me about pricing, templates, signing up, links, sharing your page or anything else on the site.' },
];

const FALLBACK = "I don't have an answer for that yet. Try asking about pricing, templates, signing up, links, sharing your page or the affiliate programme, or use the Contact page for anything else.";
const SUGGESTIONS = ['What is mavvlink?', 'How much does it cost?', 'How do I sign up?', 'Can I use my own domain?'];

function answerFor(question: string): { text: string; link?: Link } {
  const q = question.toLowerCase().replace(/[^a-z0-9₦ ]+/g, ' ');
  let best: Entry | null = null;
  let bestScore = 0;
  for (const entry of KNOWLEDGE) {
    const score = entry.keys.reduce((n, k) => (q.includes(k) ? n + k.length : n), 0);
    if (score > bestScore) {
      best = entry;
      bestScore = score;
    }
  }
  if (!best) return { text: FALLBACK };
  return { text: best.answer, link: best.link };
}

export function Assistant({ go }: { go: (view: string) => void }) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    { from: 'bot', text: "Hi, I'm the mavvlink assistant. Ask me anything about the site." },
  ]);
  const listRef = useRef<HTMLDivElement>(null);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, typing]);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  function ask(text: string) {
    const question = text.trim();
    if (!question || typing) return;
    setMessages(m => [...m, { from: 'user', text: question }]);
    setInput('');
    setTyping(true);
    timer.current = window.setTimeout(() => {
      const reply = answerFor(question);
      setMessages(m => [...m, { from: 'bot', text: reply.text, link: reply.link }]);
      setTyping(false);
    }, 650);
  }

  return (
    <>
      <button
        className={'ai-tab' + (open ? ' hidden' : '')}
        onClick={() => setOpen(true)}
        aria-label="Ask the mavvlink assistant"
        aria-expanded={open}
      >
        <Sparkles size={16} className="ai-spark" />
        <span>Ask mavvlink</span>
      </button>

      <aside className={'ai-panel' + (open ? ' open' : '')} aria-hidden={!open} aria-label="mavvlink assistant">
        <div className="ai-head">
          <div>
            <b><Sparkles size={15} /> Ask mavvlink</b>
            <small>Answers come from this site's information.</small>
          </div>
          <button className="ai-close" onClick={() => setOpen(false)} aria-label="Close assistant"><X size={18} /></button>
        </div>

        <div className="ai-list" ref={listRef}>
          {messages.map((m, i) => (
            <div key={i} className={'ai-msg ' + m.from}>
              <p>{m.text}</p>
              {m.link && (
                <button className="ai-link" onClick={() => { go(m.link!.view); setOpen(false); }}>
                  {m.link.label} <ArrowUpRight size={14} />
                </button>
              )}
            </div>
          ))}
          {typing && (
            <div className="ai-msg bot ai-typing" aria-label="Assistant is typing">
              <span /><span /><span />
            </div>
          )}
        </div>

        <div className="ai-suggest">
          {SUGGESTIONS.map(s => (
            <button key={s} onClick={() => ask(s)} disabled={typing}>{s}</button>
          ))}
        </div>

        <form className="ai-form" onSubmit={e => { e.preventDefault(); ask(input); }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Ask about the site…"
            aria-label="Your question"
          />
          <button type="submit" disabled={!input.trim() || typing} aria-label="Send">
            <ChevronRight size={18} />
          </button>
        </form>
      </aside>
    </>
  );
}
