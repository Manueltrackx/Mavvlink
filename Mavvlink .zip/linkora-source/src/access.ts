// Access rules for the dashboard. Subscribers get every template and up to 12 products.
// Unsubscribed (Free, cancelled or expired) accounts get two templates and two products.
// The server enforces the product limit; template choice is enforced in the dashboard.

export const FREE_TEMPLATE_IDS = ['studio', 'consultant'];
export const FREE_PRODUCT_LIMIT = 2;
export const SUBSCRIBER_PRODUCT_LIMIT = 12;

export type AccessInfo = { plan?: string; subscriptionStatus?: string; expiresAt?: string };

export function isSubscriber(p: AccessInfo): boolean {
  if (!p.plan || p.plan === 'Free') return false;
  if (p.subscriptionStatus !== 'active') return false;
  if (p.expiresAt && new Date(p.expiresAt).getTime() < Date.now()) return false;
  return true;
}

export function productLimit(p: AccessInfo): number {
  return isSubscriber(p) ? SUBSCRIBER_PRODUCT_LIMIT : FREE_PRODUCT_LIMIT;
}

export function templateAllowed(id: string, p: AccessInfo): boolean {
  return isSubscriber(p) || FREE_TEMPLATE_IDS.includes(id);
}

// Custom domains: Growth and Pro subscribers (Pro includes everything in Growth).
export function canUseCustomDomain(p: AccessInfo & { plan?: string }): boolean {
  return isSubscriber(p) && (p.plan === 'Growth' || p.plan === 'Pro');
}
