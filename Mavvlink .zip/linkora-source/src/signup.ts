// Sign-up details are kept until the user returns from sign-in, then used to set up
// a brand-new account. Only the sign-up form and the setup step use this module.

export type SignupDraft = {
  name: string;
  business: string;
  email: string;
  slug: string;
  ref?: string;
};

const DRAFT_KEY = 'linkora-signup-draft';

// Matches the backend rule: 3 to 39 characters, lowercase letters, digits and hyphens.
const SLUG_RULE = /^[a-z0-9][a-z0-9-]{2,38}$/;
const EMAIL_RULE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const RESERVED = [
  'admin', 'api', 'login', 'signup', 'dashboard', 'pricing', 'templates', 'examples',
  'help', 'contact', 'terms', 'privacy', 'changelog', 'about', 'services', 'www', 'p', 'linkora', 'mavvlink',
];

export function cleanSlug(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-{2,}/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 39);
}

export function validateSignup(d: SignupDraft, accepted: boolean): Partial<Record<keyof SignupDraft | 'terms', string>> {
  const errors: Partial<Record<keyof SignupDraft | 'terms', string>> = {};
  if (!d.name.trim()) errors.name = 'Enter your name.';
  if (!d.business.trim()) errors.business = 'Enter your business name.';
  else if (d.business.trim().length > 60) errors.business = 'Keep it under 60 characters.';
  if (!EMAIL_RULE.test(d.email.trim())) errors.email = 'Enter a valid email address.';
  if (!SLUG_RULE.test(d.slug)) errors.slug = 'Use 3 to 39 letters, numbers or hyphens.';
  else if (RESERVED.includes(d.slug)) errors.slug = 'That link is reserved. Try another.';
  if (!accepted) errors.terms = 'Please accept the terms to continue.';
  return errors;
}

export function saveSignupDraft(d: SignupDraft): void {
  try { localStorage.setItem(DRAFT_KEY, JSON.stringify(d)); } catch { /* storage unavailable */ }
}

export function readSignupDraft(): SignupDraft | null {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    return raw ? (JSON.parse(raw) as SignupDraft) : null;
  } catch {
    return null;
  }
}

export function clearSignupDraft(): void {
  try { localStorage.removeItem(DRAFT_KEY); } catch { /* storage unavailable */ }
}

// Referral links look like /?ref=<page-link>. The code is kept until sign-up.
const REF_KEY = 'linkora-ref';

export function saveReferral(code: string): void {
  try { localStorage.setItem(REF_KEY, code); } catch { /* storage unavailable */ }
}

export function readReferral(): string | null {
  try { return localStorage.getItem(REF_KEY); } catch { return null; }
}

export function clearReferral(): void {
  try { localStorage.removeItem(REF_KEY); } catch { /* storage unavailable */ }
}
